import sys
import os
import requests


def get_ollama_models():
    try:
        resp = requests.get("http://localhost:11434/api/tags", timeout=5)
        if resp.status_code == 200:
            models = resp.json().get("models", [])
            return [m["name"] for m in models]
        else:
            print("Failed to connect to Ollama. Is it running?")
            return []
    except Exception as e:
        print(f"Error connecting to Ollama: {e}")
        return []


def get_lmstudio_models():
    try:
        resp = requests.get("http://localhost:1234/v1/models", timeout=5)
        if resp.status_code == 200:
            models = resp.json().get("data", [])
            return [m["id"] for m in models]
        else:
            print("Failed to connect to LM Studio. Is it running?")
            return []
    except Exception as e:
        print(f"Error connecting to LM Studio: {e}")
        return []


def get_api_models(base_url, api_key):
    headers = {"Authorization": f"Bearer {api_key}"}
    try:
        resp = requests.get(f"{base_url}/v1/models", headers=headers, timeout=10)
        if resp.status_code == 200:
            models = resp.json().get("data", [])
            return [m["id"] for m in models]
        else:
            return []
    except Exception:
        return []


def pick_model(models):
    while True:
        try:
            model_idx = int(input("  Model number: ")) - 1
            if 0 <= model_idx < len(models):
                return models[model_idx]
            print(f"  Please enter a number between 1 and {len(models)}.")
        except ValueError:
            print("  Please enter a valid number.")


PROVIDER_CONFIGS = {
    "3": {
        "name": "OpenAI",
        "base_url": "https://api.openai.com",
        "model_tip": "Tip: Copy-paste from https://platform.openai.com/docs/models",
        "example": "gpt-4o",
    },
    "4": {
        "name": "DeepSeek",
        "base_url": "https://api.deepseek.com",
        "model_tip": "Tip: Copy-paste from https://platform.deepseek.com/api-docs",
        "example": "deepseek-chat",
    },
    "5": {
        "name": "OpenRouter",
        "base_url": "https://openrouter.ai/api",
        "model_tip": "Tip: Browse available models at https://openrouter.ai/models and copy-paste the model ID",
        "example": "anthropic/claude-sonnet-4",
        "force_manual": True,
    },
    "6": {
        "name": "HuggingFace",
        "base_url": "https://api-inference.huggingface.co",
        "model_tip": "Tip: Browse models at https://huggingface.co/models and copy-paste the model ID (e.g. meta-llama/Llama-3.3-70B-Instruct)",
        "example": "meta-llama/Llama-3.3-70B-Instruct",
        "force_manual": True,
    },
}


def select_provider():
    while True:
        print("\nSelect AI Provider:")
        print("  1. Ollama (local)")
        print("  2. LM Studio (local)")
        print("  3. OpenAI (API key)")
        print("  4. DeepSeek (API key)")
        print("  5. OpenRouter (API key)")
        print("  6. HuggingFace (API key)")
        print("  7. AirLLM (local large model — CPU/GPU offloading)")
        try:
            choice = input("Enter 1-7: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            sys.exit(0)

        if choice == "1":
            print("\nConnecting to Ollama...")
            models = get_ollama_models()
            if not models:
                print("Ollama not reachable. Make sure it's running (ollama serve).")
                retry = input("Retry? (y/n): ").strip().lower()
                if retry == 'y':
                    continue
                print("You can also enter a model name manually:")
                manual = input("Model name (or press Enter to exit): ").strip()
                if not manual:
                    sys.exit(1)
                selected_model = manual
            else:
                print("Available models:")
                for idx, m in enumerate(models):
                    print(f"  {idx+1}. {m}")
                selected_model = pick_model(models)
            provider_type = "ollama"
            api_key = None
            base_url = None

        elif choice == "2":
            print("\nConnecting to LM Studio...")
            models = get_lmstudio_models()
            if not models:
                print("LM Studio not reachable. Make sure the server is running on port 1234.")
                retry = input("Retry? (y/n): ").strip().lower()
                if retry == 'y':
                    continue
                print("You can also enter a model name manually:")
                manual = input("Model name (or press Enter to exit): ").strip()
                if not manual:
                    sys.exit(1)
                selected_model = manual
            else:
                print("Available models:")
                for idx, m in enumerate(models):
                    print(f"  {idx+1}. {m}")
                selected_model = pick_model(models)
            provider_type = "lmstudio"
            api_key = None
            base_url = "http://localhost:1234"

        elif choice in PROVIDER_CONFIGS:
            cfg = PROVIDER_CONFIGS[choice]
            print(f"\n--- {cfg['name']} Setup ---")
            api_key = input(f"Enter {cfg['name']} API key: ").strip()
            if not api_key:
                print("API key is required.")
                continue

            base_url = cfg["base_url"]

            if cfg.get("force_manual"):
                print(f"\n{cfg['name']} requires you to enter the exact model name.")
                print(f"  {cfg['model_tip']}")
                print(f"  Example: {cfg['example']}")
                selected_model = input("Model name: ").strip()
                if not selected_model:
                    sys.exit(1)
            else:
                print(f"Fetching available models from {cfg['name']}...")
                models = get_api_models(base_url, api_key)
                if models:
                    print("Available models:")
                    for idx, m in enumerate(models):
                        print(f"  {idx+1}. {m}")
                    selected_model = pick_model(models)
                else:
                    print(f"Could not fetch models from {cfg['name']}.")
                    print(f"  {cfg['model_tip']}")
                    print(f"  Example: {cfg['example']}")
                    selected_model = input("Model name: ").strip()
                    if not selected_model:
                        sys.exit(1)

            provider_type = "api"

        elif choice == "7":
            print("\n--- AirLLM: Local Large Model Setup ---")
            print("AirLLM runs large models (70B+) on consumer hardware by loading")
            print("one layer at a time into GPU/CPU — no massive VRAM needed.")
            print("Requires: pip install airllm (and bitsandbytes for 4bit compression)")
            print()
            print("Enter the model location:")
            print("  - Local folder path: /home/user/models/Llama-3.3-70B")
            print("  - HuggingFace repo ID: meta-llama/Llama-3.3-70B-Instruct")
            model_path = input("Model path or HF repo ID: ").strip()
            if not model_path:
                sys.exit(1)

            print("\nSelect device:")
            print("  1. CUDA GPU (recommended)")
            print("  2. CPU only (very slow)")
            dev_choice = input("Enter 1 or 2 [1]: ").strip() or "1"
            device = "cuda:0" if dev_choice == "1" else "cpu"

            seq_input = input("Max sequence length [2048]: ").strip()
            max_seq_len = int(seq_input) if seq_input else 2048

            print("\nCompression (requires bitsandbytes):")
            print("  1. None (full precision)")
            print("  2. 4-bit (recommended for 70B+ models)")
            comp_choice = input("Enter 1 or 2 [2]: ").strip() or "2"
            compression = "4bit" if comp_choice == "2" else None

            hf_token = input("HuggingFace token for gated models (or press Enter): ").strip() or None

            selected_model = model_path
            provider_type = "airllm"
            api_key = hf_token
            base_url = None

        else:
            print("Invalid choice. Enter a number between 1 and 7.")
            continue

        break

    print(f"\nSelected model: {selected_model}")
    config = {
        "provider_type": provider_type,
        "model": selected_model,
        "api_key": api_key,
        "base_url": base_url,
    }
    if provider_type == "airllm":
        config["airllm_device"] = device
        config["airllm_max_seq_len"] = max_seq_len
        config["airllm_compression"] = compression
    return config
