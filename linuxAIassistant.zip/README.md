# Linux OS AI Assistant

An AI-powered assistant for Linux that can execute bash commands, search the web, and answer questions using local or cloud AI models.

## Features

- **Multiple AI backends**: Ollama (local), LM Studio (local), or API-based (OpenAI, Anthropic, OpenRouter, DeepSeek, custom)
- **System command execution**: Run bash commands directly with `!bash`
- **AI-driven command proposals**: The AI suggests commands in code blocks for you to review and execute safely
- **Sudo mode**: Automatically prefix commands with `sudo` when needed
- **Web search**: Automatic or manual web search via DuckDuckGo
- **Self-updating search engine**: Automatically checks for and applies `ddgs` library updates from PyPI
- **Browser automation**: Control a real web browser via Playwright — navigate, click, type, extract data, take screenshots (`/browser` mode or `!browse` direct command)
- **DuckDuckGo search in browser**: Default search engine in browser mode is DuckDuckGo, with full page interaction
- **Command logging**: Each executed command is logged to `command_logs/` with structured files
- **Action review**: Use `/logs` and `/review` to have the AI inspect past commands for mistakes
- **Conversation context management**: Automatically trims history to prevent model confusion

## Requirements

- Python 3.7+
- `bash` shell
- One of the following AI backends:
  - [Ollama](https://ollama.com) — run models locally
  - [LM Studio](https://lmstudio.ai) — run models locally
  - An API key from [OpenAI](https://openai.com), [Anthropic](https://claude.ai), [OpenRouter](https://openrouter.ai), [DeepSeek](https://deepseek.com), etc.

## Installation

```bash
pip install -r requirements.txt
python -m playwright install chromium
```

## Usage

```bash
python main.py
```

The assistant will guide you through:
1. **Sudo mode** — enable/disable automatic `sudo` prefixing for commands
2. **AI provider** — select Ollama, LM Studio, or API key provider
3. **Model selection** — pick from available models
4. **Chat loop** — interact with the AI

### Chat Commands

| Command | Description |
|---------|-------------|
| `exit` | Exit the assistant |
| `/search <query>` | Force a web search on any topic |
| `/toggle` | Enable/disable automatic web search |
| `/logs [N]` | Show the last N command logs and have the AI review them |
| `/clearcommandlogs` | Delete all command logs from command_logs/ |
| `/review` | Have the AI inspect recent commands for mistakes |
| `/build <desc>` | Enter auto-build mode — AI plans and builds step by step |
| `/fullyauto [goal]` | Enter fully autonomous mode — AI takes full control |
| `/browser [--visible] [url]` | Enter browser automation mode — AI controls a web browser (add `--visible` to watch it) |
| `!bash <command>` | Execute a bash command directly |
| `!browse <action>` | Direct browser command (go, click, type, extract, etc.) |

### How AI Command Execution Works

1. Ask the AI to perform a system task (e.g., *"list files in /home"*)
2. The AI responds with a command inside a ` ```bash ` code block
3. You **review and confirm** before the command runs
4. The output is fed back to the AI for further discussion

The AI never executes commands without your explicit confirmation.

### Command Logs

Every executed command is saved as an individual file in `command_logs/`:

```
cmd_20260515_045231_0003.log
  Timestamp : 2026-05-15 04:52:31
  Shell     : bash
  Exit Code : 1
  Status    : FAILED
  Command   : apt install nonexistent
  ============================================================
  Output:
  E: Unable to locate package
```

Use `/logs 5` to show recent logs, or `/review` to have the AI check its past commands for errors.

### Auto-Updating Search Engine

The search library (`ddgs`) is automatically checked against PyPI once per day. If a newer version is available, it's updated in the background before the next search. Disable this in `assistant_core/config.json`:

```json
{"auto_update": false, "auto_update_interval_hours": 24}
```

## Model Sources

| Source | Type | URL |
|--------|------|-----|
| Ollama | Local & Cloud | https://ollama.com |
| HuggingFace | Local & Cloud | https://huggingface.co |
| OpenRouter | Cloud (API key) | https://openrouter.ai |
| OpenAI | Cloud (API key) | https://openai.com |
| Anthropic | Cloud (API key) | https://claude.ai |
| DeepSeek | Cloud (API key) | https://deepseek.com |

## Important Notes

- The assistant has limited context memory (last ~20 turns). Excessive history can confuse the model.
- This is not a system repair tool. The AI can make mistakes. Always review commands before execution.
- For complex tasks, use larger models (e.g., Qwen3-Coder:480B) via cloud API if your local hardware is insufficient.
- Larger parameter models (more "brain size") generally produce better results for complex tasks.

## Project Structure

```
linuxAIassistant/
├── main.py                  # Entry point and chat loop
├── executor.py              # Bash command execution
├── browser_agent.py         # Playwright-based browser automation
├── .gitignore
├── LICENSE
├── MODEL_RECOMMENDATIONS.md
├── README.md
├── requirements.txt
└── command_logs/            # Per-command execution logs
    └── .gitkeep
└── assistant_core/
    ├── __init__.py
    ├── config.json          # Auto-update settings
    ├── llm.py               # LLM API communication
    ├── provider.py          # AI provider selection and model listing
    ├── search.py            # Low-level DuckDuckGo search
    ├── search_engine.py     # Search interface with auto-update
    └── update_manager.py    # PyPI version check and package update
```
