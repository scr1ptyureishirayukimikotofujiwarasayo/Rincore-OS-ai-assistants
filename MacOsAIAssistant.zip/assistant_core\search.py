import socket
import time


def check_internet():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except OSError:
        return False


def web_search(query, max_results=3, retries=1):
    if not query or not query.strip():
        return []

    for attempt in range(retries + 1):
        try:
            from ddgs import DDGS
            with DDGS(timeout=10) as ddgs:
                results = list(ddgs.text(query.strip(), max_results=max_results))
                safe = []
                for r in results:
                    safe.append({
                        "title": r.get("title", ""),
                        "body": r.get("body", ""),
                        "href": r.get("href", ""),
                    })
                return safe
        except ImportError:
            print("Search unavailable: 'ddgs' package not installed. Run: pip install ddgs")
            return []
        except Exception as e:
            if attempt < retries:
                time.sleep(1)
                continue
            print(f"Search error: {e}")
            return []

    return []
