import requests

_airllm_model = None


def generate_response(messages, config):
    provider = config["provider_type"]
    model = config["model"]
    temperature = config.get("temperature", 0.3)

    if provider == "ollama":
        url = "http://localhost:11434/api/chat"
        payload = {"model": model, "messages": messages, "stream": False, "options": {"temperature": temperature}}
        try:
            resp = requests.post(url, json=payload, timeout=60)
            if resp.status_code == 200:
                return resp.json()["message"]["content"]
            else:
                return f"Error: {resp.text}"
        except Exception as e:
            return f"Error: {e}"

    elif provider == "lmstudio":
        url = f"{config['base_url']}/v1/chat/completions"
        headers = {"Content-Type": "application/json"}
        payload = {"model": model, "messages": messages, "stream": False, "temperature": temperature}
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=60)
            if resp.status_code == 200:
                return resp.json()["choices"][0]["message"]["content"]
            else:
                return f"Error: {resp.text}"
        except Exception as e:
            return f"Error: {e}"

    elif provider == "api":
        url = f"{config['base_url']}/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {config['api_key']}"
        }
        payload = {"model": model, "messages": messages, "stream": False, "temperature": temperature}
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=60)
            if resp.status_code == 200:
                return resp.json()["choices"][0]["message"]["content"]
            else:
                return f"Error: {resp.text}"
        except Exception as e:
            return f"Error: {e}"

    elif provider == "huggingface":
        api_key = config["api_key"]
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        payload = {"model": model, "messages": messages, "stream": False,
                    "temperature": temperature, "max_tokens": 1024}
        try:
            resp = requests.post(
                f"https://api-inference.huggingface.co/models/{model}/v1/chat/completions",
                json=payload, headers=headers, timeout=60
            )
            if resp.status_code == 200:
                return resp.json()["choices"][0]["message"]["content"]
            if resp.status_code == 404:
                prompt = _hf_format_prompt(messages)
                resp2 = requests.post(
                    f"https://api-inference.huggingface.co/models/{model}",
                    json={"inputs": prompt, "parameters": {"temperature": temperature, "max_new_tokens": 1024}},
                    headers=headers, timeout=60
                )
                if resp2.status_code == 200:
                    result = resp2.json()
                    if isinstance(result, list) and result:
                        return result[0].get("generated_text", "")
                    if isinstance(result, dict):
                        return result.get("generated_text", str(result))
                return f"Error: {resp2.text}"
            return f"Error: {resp.text}"
        except Exception as e:
            return f"Error: {e}"

    elif provider == "airllm":
        return _airllm_generate(messages, config)

    else:
        return "Unknown provider"


def _hf_format_prompt(messages):
    parts = []
    for m in messages:
        role = m.get("role", "user")
        content = m.get("content", "")
        if role == "system":
            parts.append(f"System: {content}")
        elif role == "user":
            parts.append(f"User: {content}")
        elif role == "assistant":
            parts.append(f"Assistant: {content}")
    return "\n".join(parts)


def _patch_airllm_deps():
    """Fix broken optimum.bettertransformer dependency in airllm."""
    import sys, types
    bt = types.ModuleType("optimum.bettertransformer")
    bt.BetterTransformer = type("BetterTransformer", (), {
        "transform": staticmethod(lambda model, **kw: model)
    })
    sys.modules["optimum.bettertransformer"] = bt
    sys.modules["optimum.bettertransformer.models"] = types.ModuleType(
        "optimum.bettertransformer.models"
    )


def _airllm_generate(messages, config):
    global _airllm_model
    try:
        from airllm import AutoModel
    except (ImportError, ModuleNotFoundError) as e:
        # Try patching the broken optimum.bettertransformer dependency
        try:
            _patch_airllm_deps()
            from airllm import AutoModel
        except Exception:
            import importlib.util
            has_pkg = importlib.util.find_spec("airllm") is not None
            if has_pkg:
                return (
                    f"Error: airllm is installed but failed to load due to missing dependencies.\n"
                    f"  {e}\n"
                    f"  Run: pip install optimum accelerate\n"
                )
            return "Error: airllm not installed. Run: pip install airllm"

    if _airllm_model is None:
        model_path = config["model"]
        device = config.get("airllm_device", "cuda:0")
        max_seq_len = config.get("airllm_max_seq_len", 2048)
        compression = config.get("airllm_compression")
        hf_token = config.get("api_key")

        try:
            _airllm_model = AutoModel.from_pretrained(
                model_path,
                device=device,
                max_seq_len=max_seq_len,
                compression=compression,
                hf_token=hf_token,
            )
        except Exception as e:
            _airllm_model = None
            return f"Error loading model: {e}"

    try:
        prompt = _airllm_model.tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        input_ids = _airllm_model.tokenizer(prompt, return_tensors="pt").input_ids
        device = config.get("airllm_device", "cuda:0")
        if "cuda" in device:
            input_ids = input_ids.cuda()
        output = _airllm_model.generate(
            input_ids,
            max_new_tokens=1024,
            temperature=config.get("temperature", 0.3),
            do_sample=True,
            pad_token_id=_airllm_model.tokenizer.eos_token_id,
        )
        response = _airllm_model.tokenizer.decode(
            output[0][input_ids.shape[1]:], skip_special_tokens=True
        )
        return response
    except Exception as e:
        return f"Error during generation: {e}"
