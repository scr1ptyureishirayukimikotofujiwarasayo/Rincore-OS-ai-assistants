import os
import time
from datetime import datetime

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    sync_playwright = None

_SCREENSHOT_DIR = "browser_screenshots"

# Common popup/modal selectors to auto-close
_POPUP_SELECTORS = [
    "button:has-text('Accept')",
    "button:has-text('Accept All')",
    "button:has-text('Accept all')",
    "button:has-text('Agree')",
    "button:has-text('Got it')",
    "button:has-text('Continue')",
    "button:has-text('OK')",
    "button:has-text('Close')",
    "button[aria-label='Close']",
    "button.close",
    ".modal .close",
    ".modal button:has-text('Close')",
    "[class*='cookie'] button:has-text('Accept')",
    "[class*='cookie'] button:has-text('OK')",
    "[id*='cookie'] button:has-text('Accept')",
    "[id*='cookie'] button:has-text('OK')",
    ".popup button:has-text('Close')",
    ".overlay button:has-text('Close')",
    ".fc-button.fc-cta-consent",
    ".fc-button.fc-confirm-choices",
    ".cc-btn.cc-allow",
    ".cc-btn.cc-dismiss",
    "#onetrust-accept-btn-handler",
    ".cmp-button.cmp-accept",
    ".qc-cmp-button",
]

# Captcha detection selectors
_CAPTCHA_SELECTORS = [
    "iframe[src*='captcha']",
    "iframe[src*='recaptcha']",
    "iframe[src*='hcaptcha']",
    "[class*='g-recaptcha']",
    "[class*='h-captcha']",
    "[id*='captcha']",
    "[class*='captcha']",
    ".recaptcha-checkbox-border",
    "iframe[title*='captcha']",
    "iframe[title*='recaptcha']",
    "iframe[title*='hcaptcha']",
    "[data-sitekey]",
]


class BrowserAgent:
    def __init__(self, headless=True):
        self._playwright = None
        self._browser = None
        self._page = None
        self.headless = headless
        self._last_result = ""

    def start(self):
        if sync_playwright is None:
            return "Playwright is not installed. Run: pip install playwright && python -m playwright install chromium"
        self._playwright = sync_playwright().start()
        self._browser = self._playwright.chromium.launch(
            headless=self.headless,
            args=["--no-sandbox", "--disable-setuid-sandbox"]
        )
        self._page = self._browser.new_page()
        self._page.set_viewport_size({"width": 1280, "height": 800})
        return "Browser started (headless)" if self.headless else "Browser started (visible)"

    def _close_common_popups(self):
        """Try to close any visible popups/modals silently."""
        if not self._page:
            return
        for selector in _POPUP_SELECTORS:
            try:
                el = self._page.query_selector(selector)
                if el and el.is_visible():
                    el.click()
                    self._page.wait_for_timeout(300)
            except Exception:
                pass

    def close_popups(self):
        """Detect and close common popup windows (cookie banners, modals, etc.)."""
        if not self._page:
            return "Browser not started."
        closed = []
        for selector in _POPUP_SELECTORS:
            try:
                el = self._page.query_selector(selector)
                if el and el.is_visible():
                    el.click()
                    self._page.wait_for_timeout(300)
                    closed.append(selector)
            except Exception:
                pass
        if closed:
            self._last_result = f"Closed {len(closed)} popup(s): {', '.join(closed[:5])}"
        else:
            self._last_result = "No visible popups found."
        return self._last_result

    def detect_captcha(self):
        """Check if a captcha is present on the page. Returns details or None."""
        if not self._page:
            return "Browser not started."
        found = []
        for selector in _CAPTCHA_SELECTORS:
            try:
                el = self._page.query_selector(selector)
                if el and el.is_visible():
                    tag = el.evaluate("el => el.tagName")
                    src = (el.get_attribute("src") or el.get_attribute("data-sitekey") or "")[:80]
                    found.append({"selector": selector, "tag": tag, "detail": src})
            except Exception:
                pass
        if found:
            self._last_result = f"Captcha detected: {found}"
            return self._last_result
        self._last_result = "No captcha detected."
        return None

    def handle_captcha(self):
        """Try to handle a captcha. Returns True if handled, False if manual intervention needed."""
        if not self._page:
            return "Browser not started."
        found = self.detect_captcha()
        if not found:
            return "No captcha to handle."

        try:
            recaptcha_checkbox = self._page.query_selector(".recaptcha-checkbox-border")
            if recaptcha_checkbox and recaptcha_checkbox.is_visible():
                recaptcha_checkbox.click()
                self._page.wait_for_timeout(2000)
                self._last_result = "Clicked reCAPTCHA checkbox. Check if solved."
                return self._last_result
        except Exception:
            pass

        try:
            hcaptcha_checkbox = self._page.query_selector("#checkbox")
            if hcaptcha_checkbox and hcaptcha_checkbox.is_visible():
                hcaptcha_checkbox.click()
                self._page.wait_for_timeout(2000)
                self._last_result = "Clicked hCaptcha checkbox. Check if solved."
                return self._last_result
        except Exception:
            pass

        shot = self.screenshot()
        return (f"Captcha requires manual solving.\n"
                f"A screenshot was taken: {shot}\n"
                f"Solve the captcha, then call close_popups() and retry.")

    def navigate(self, url):
        if not self._page:
            return "Browser not started."
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        try:
            self._page.goto(url, timeout=30000, wait_until="domcontentloaded")
            self._page.wait_for_timeout(1500)
            self._close_common_popups()
            title = self._page.title()
            captcha = self.detect_captcha()
            result = f"Navigated to: {url}\nTitle: {title}"
            if captcha:
                result += f"\n⚠ {captcha}"
            self._last_result = result
            return self._last_result
        except Exception as e:
            return f"Navigation error: {e}"

    def search(self, query, engine="duckduckgo"):
        if not self._page:
            return "Browser not started."
        q = query.replace(" ", "+")

        engines = {
            "duckduckgo": f"https://duckduckgo.com/?q={q}",
            "google": f"https://www.google.com/search?q={q}",
            "bing": f"https://www.bing.com/search?q={q}",
            "brave": f"https://search.brave.com/search?q={q}",
        }

        url = engines.get(engine, engines["duckduckgo"])
        selectors = {
            "duckduckgo": ["article", ".result", ".results--main a", "h2 a"],
            "google": ["#search a[href^='http']", "div.g a[href^='http']", "h3"],
            "bing": ["#b_results h2 a", "li.b_algo h2 a"],
            "brave": [".snippet", ".result"],
        }

        try:
            self._page.goto(url, timeout=30000, wait_until="domcontentloaded")
            self._page.wait_for_timeout(2000)
            self._close_common_popups()

            captcha = self.detect_captcha()
            if captcha:
                self._last_result = self.handle_captcha()
                return self._last_result

            sel = selectors.get(engine, selectors["duckduckgo"])
            for s in sel:
                links = self._page.query_selector_all(s)
                if len(links) >= 3:
                    break

            title = self._page.title()
            body = self._page.inner_text("body")[:3000]
            self._last_result = f"{engine.capitalize()} search: {query}\nTitle: {title}\n\n{body}"
            return self._last_result
        except Exception as e:
            if "captcha" in str(e).lower() or "blocked" in str(e).lower():
                return self._fallback_search(query, engines, selectors)
            return f"Search error on {engine}: {e}"

    def _fallback_search(self, query, engines, selectors):
        """Try alternative search engines when one is blocked."""
        engines.pop("duckduckgo", None)
        for engine, search_url in engines.items():
            try:
                self._page.goto(search_url, timeout=30000, wait_until="domcontentloaded")
                self._page.wait_for_timeout(2000)
                self._close_common_popups()
                sel = selectors.get(engine, selectors["duckduckgo"])
                title = self._page.title()
                body = self._page.inner_text("body")[:3000]
                result = f"Switched to {engine}. Search: {query}\nTitle: {title}\n\n{body}"
                self._last_result = result
                return result
            except Exception:
                continue
        return f"All search engines blocked by captcha or rate limiting."

    def click(self, selector):
        if not self._page:
            return "Browser not started."
        try:
            el = self._page.wait_for_selector(selector, timeout=5000)
            if not el:
                return f"Element not found: {selector}"
            el.click()
            self._page.wait_for_timeout(1000)
            self._last_result = f"Clicked: {selector}\nNew URL: {self._page.url}\nTitle: {self._page.title()}"
            return self._last_result
        except Exception as e:
            return f"Click error on '{selector}': {e}"

    def type_text(self, selector, text):
        if not self._page:
            return "Browser not started."
        try:
            el = self._page.wait_for_selector(selector, timeout=5000)
            if not el:
                return f"Element not found: {selector}"
            el.fill("")
            el.type(text, delay=20)
            self._last_result = f"Typed '{text}' into {selector}"
            return self._last_result
        except Exception as e:
            return f"Type error: {e}"

    def extract(self, selector=None):
        if not self._page:
            return "Browser not started."
        try:
            if selector:
                els = self._page.query_selector_all(selector)
                texts = [el.inner_text().strip() for el in els if el.inner_text().strip()]
                result = "\n---\n".join(texts) if texts else f"No elements matched '{selector}'"
            else:
                result = self._page.inner_text("body")
            self._last_result = result[:5000]
            return self._last_result
        except Exception as e:
            return f"Extract error: {e}"

    def html(self):
        if not self._page:
            return "Browser not started."
        try:
            content = self._page.content()
            self._last_result = content[:5000]
            return self._last_result
        except Exception as e:
            return f"HTML error: {e}"

    def scroll(self, direction="down", amount=800):
        if not self._page:
            return "Browser not started."
        delta = amount if direction == "down" else -amount
        try:
            self._page.evaluate(f"window.scrollBy(0, {delta})")
            self._page.wait_for_timeout(500)
            self._last_result = f"Scrolled {direction} {amount}px"
            return self._last_result
        except Exception as e:
            return f"Scroll error: {e}"

    def screenshot(self, path=None):
        if not self._page:
            return "Browser not started."
        os.makedirs(_SCREENSHOT_DIR, exist_ok=True)
        if not path:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = os.path.join(_SCREENSHOT_DIR, f"screenshot_{ts}.png")
        try:
            self._page.screenshot(path=path, full_page=True)
            self._last_result = f"Screenshot saved: {path}"
            return self._last_result
        except Exception as e:
            return f"Screenshot error: {e}"

    def execute_script(self, js):
        if not self._page:
            return "Browser not started."
        try:
            result = self._page.evaluate(js)
            self._last_result = f"Script result: {result}"
            return self._last_result
        except Exception as e:
            return f"Script error: {e}"

    def get_url(self):
        if not self._page:
            return "Browser not started."
        return self._page.url

    def get_title(self):
        if not self._page:
            return "Browser not started."
        return self._page.title()

    def press_key(self, key):
        if not self._page:
            return "Browser not started."
        try:
            self._page.keyboard.press(key)
            self._page.wait_for_timeout(500)
            self._last_result = f"Pressed key: {key}"
            return self._last_result
        except Exception as e:
            return f"Key press error: {e}"

    def wait(self, ms):
        if not self._page:
            return "Browser not started."
        self._page.wait_for_timeout(ms)
        return f"Waited {ms}ms"

    def select_option(self, selector, value):
        if not self._page:
            return "Browser not started."
        try:
            self._page.select_option(selector, value)
            self._last_result = f"Selected '{value}' in {selector}"
            return self._last_result
        except Exception as e:
            return f"Select error: {e}"

    def close(self):
        if self._page:
            self._page.close()
            self._page = None
        if self._browser:
            self._browser.close()
            self._browser = None
        if self._playwright:
            self._playwright.stop()
            self._playwright = None
        return "Browser closed."

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.close()


def process_browse_command(browser, cmd_line):
    if not browser or not browser._page:
        return "Browser not started. Use 'start' first."
    parts = cmd_line.strip().split(maxsplit=1)
    if not parts:
        return "Usage: <action> [args...]"
    action = parts[0].lower()
    args = parts[1] if len(parts) > 1 else ""

    handlers = {
        "go": lambda: browser.navigate(args.strip()),
        "navigate": lambda: browser.navigate(args.strip()),
        "search": lambda: browser.search(args.strip()),
        "click": lambda: browser.click(args.strip()),
        "type": lambda: browser.type_text(*(args.split(maxsplit=1))),
        "extract": lambda: browser.extract(args.strip() or None),
        "html": lambda: browser.html(),
        "scroll": lambda: browser.scroll(args.strip().lower() or "down"),
        "screenshot": lambda: browser.screenshot(args.strip() or None),
        "url": lambda: f"Current URL: {browser.get_url()}",
        "title": lambda: f"Page title: {browser.get_title()}",
        "script": lambda: browser.execute_script(args.strip()),
        "press": lambda: browser.press_key(args.strip()),
        "wait": lambda: browser.wait(int(args.strip())),
        "select": lambda: browser.select_option(*(args.split(maxsplit=1))),
        "close": lambda: browser.close(),
        "popups": lambda: browser.close_popups(),
        "captcha": lambda: browser.detect_captcha() or "No captcha found.",
        "solve-captcha": lambda: browser.handle_captcha(),
    }
    handler = handlers.get(action)
    if not handler:
        actions = ", ".join(sorted(handlers))
        return f"Unknown action: {action}. Available: {actions}"
    try:
        return handler()
    except Exception as e:
        return f"Error executing '{action}': {e}"
