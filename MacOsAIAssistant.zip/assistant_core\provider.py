import sys
import requests


def get_ollama_models():
    try:
        resp = requests.get("http://localhost:11434/api/tags", timeout=5)
        if resp.status_code == 200:
            models = resp.json().get("models", [])
            return [m["name"] for m in models]
        else:
            print("Failed to connect to Ollama. Is it running?")
            return []
    except Exception as e:
        print(f"Error connecting to Ollama: {e}")
        return []


def get_lmstudio_models():
    try:
        resp = requests.get("http://localhost:1234/v1/models", timeout=5)
        if resp.status_code == 200:
            models = resp.json().get("data", [])
            return [m["id"] for m in models]
        else:
            print("Failed to connect to LM Studio. Is it running?")
            return []
    except Exception as e:
        print(f"Error connecting to LM Studio: {e}")
        return []


def get_api_models(base_url, api_key):
    headers = {"Authorization": f"Bearer {api_key}"}
    try:
        resp = requests.get(f"{base_url}/v1/models", headers=headers, timeout=10)
        if resp.status_code == 200:
            models = resp.json().get("data", [])
            return [m["id"] for m in models]
        else:
            print(f"Failed to get models: {resp.text}")
            return []
    except Exception as e:
        print(f"Error: {e}")
        return []


def pick_model(models):
    while True:
        try:
            model_idx = int(input("Select model number: ")) - 1
            if 0 <= model_idx < len(models):
                return models[model_idx]
            print(f"Please enter a number between 1 and {len(models)}.")
        except ValueError:
            print("Please enter a valid number.")


def select_provider():
    while True:
        print("\nSelect AI Provider:")
        print("1. Ollama (local)")
        print("2. LM Studio (local)")
        print("3. API Keys (OpenAI, Anthropic, custom)")
        try:
            provider_choice = input("Enter 1, 2, or 3: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            sys.exit(0)

        if provider_choice == "1":
            print("\nConnecting to Ollama...")
            models = get_ollama_models()
            if not models:
                print("Ollama not reachable. Make sure it's running (ollama serve).")
                retry = input("Retry? (y/n): ").strip().lower()
                if retry == 'y':
                    continue
                print("You can also enter a model name manually:")
                manual = input("Model name (or press Enter to exit): ").strip()
                if not manual:
                    sys.exit(1)
                selected_model = manual
            else:
                print("Available models:")
                for idx, m in enumerate(models):
                    print(f"{idx+1}. {m}")
                selected_model = pick_model(models)
            provider_type = "ollama"
            api_key = None
            base_url = None

        elif provider_choice == "2":
            print("\nConnecting to LM Studio...")
            models = get_lmstudio_models()
            if not models:
                print("LM Studio not reachable. Make sure the server is running on port 1234.")
                retry = input("Retry? (y/n): ").strip().lower()
                if retry == 'y':
                    continue
                print("You can also enter a model name manually:")
                manual = input("Model name (or press Enter to exit): ").strip()
                if not manual:
                    sys.exit(1)
                selected_model = manual
            else:
                print("Available models:")
                for idx, m in enumerate(models):
                    print(f"{idx+1}. {m}")
                selected_model = pick_model(models)
            provider_type = "lmstudio"
            api_key = None
            base_url = "http://localhost:1234"

        elif provider_choice == "3":
            print("\nAPI Key Provider Setup")
            api_key = input("Enter API key: ").strip()
            base_url = input("Enter base URL (e.g., https://api.openai.com or http://localhost:1234): ").strip()
            if not base_url.startswith("http"):
                base_url = "https://" + base_url
            base_url = base_url.rstrip("/")
            print(f"Fetching models from {base_url}...")
            models = get_api_models(base_url, api_key)
            if not models:
                print("No models found or failed to fetch. You may still proceed with a manual model name.")
                manual_model = input("Enter model name manually (or press Enter to exit): ").strip()
                if not manual_model:
                    sys.exit(1)
                selected_model = manual_model
            else:
                print("Available models:")
                for idx, m in enumerate(models):
                    print(f"{idx+1}. {m}")
                selected_model = pick_model(models)
            provider_type = "api"
        else:
            print("Invalid choice. Enter 1, 2, or 3.")
            continue

        break

    print(f"\nSelected model: {selected_model}")
    return {
        "provider_type": provider_type,
        "model": selected_model,
        "api_key": api_key,
        "base_url": base_url,
    }
