import sys
import os
import subprocess
import shutil
import requests


def get_ollama_models():
    try:
        resp = requests.get("http://localhost:11434/api/tags", timeout=5)
        if resp.status_code == 200:
            models = resp.json().get("models", [])
            return [m["name"] for m in models]
        else:
            print("Failed to connect to Ollama. Is it running?")
            return []
    except Exception as e:
        print(f"Error connecting to Ollama: {e}")
        return []


def ollama_pull(name):
    print(f"\nPulling {name}...")
    try:
        subprocess.run(["ollama", "pull", name], check=True)
        return True
    except Exception as e:
        print(f"Failed to pull model: {e}")
        return False


def ollama_remove(name):
    try:
        subprocess.run(["ollama", "rm", name], check=True)
        print(f"Removed {name}")
        return True
    except Exception as e:
        print(f"Failed to remove model: {e}")
        return False


def get_lmstudio_models():
    try:
        resp = requests.get("http://localhost:1234/v1/models", timeout=5)
        if resp.status_code == 200:
            models = resp.json().get("data", [])
            return [m["id"] for m in models]
        else:
            print("Failed to connect to LM Studio. Is it running?")
            return []
    except Exception as e:
        print(f"Error connecting to LM Studio: {e}")
        return []


def get_api_models(base_url, api_key):
    headers = {"Authorization": f"Bearer {api_key}"}
    try:
        resp = requests.get(f"{base_url}/v1/models", headers=headers, timeout=10)
        if resp.status_code == 200:
            models = resp.json().get("data", [])
            return [m["id"] for m in models]
        else:
            return []
    except Exception:
        return []


def pick_model(models):
    while True:
        try:
            model_idx = int(input("  Model number: ")) - 1
            if 0 <= model_idx < len(models):
                return models[model_idx]
            print(f"  Please enter a number between 1 and {len(models)}.")
        except ValueError:
            print("  Please enter a valid number.")


def browse_folder():
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        path = filedialog.askdirectory(title="Select model folder")
        root.destroy()
        return path or ""
    except Exception:
        return input("File dialog unavailable. Paste full folder path: ").strip()


def local_model_menu(provider_name, models, fetch_fn, can_install=True, can_remove=True):
    """Reusable sub-menu for local providers (Ollama, LM Studio, AirLLM folders)."""
    refresh = models
    while True:
        if refresh is not None:
            models = refresh
            refresh = None

        if models:
            print(f"\n  Installed models ({len(models)}):")
            for idx, m in enumerate(models):
                print(f"    {idx+1}. {m}")
        else:
            print(f"\n  No models found.")

        opts = ["Select a model to use"]
        if can_install:
            opts.append(f"Install a new model")
        if can_remove:
            opts.append(f"Remove a model")
        opts.append("Refresh model list")
        opts.append("Enter model name manually")
        opts.append("Go back")

        print(f"\n  What would you like to do?")
        for i, o in enumerate(opts):
            print(f"    {i+1}. {o}")

        sub = input("  Choice: ").strip()
        offset = 0

        if sub == "1":
            if not models:
                print("  No models available. Install one first.")
                continue
            return pick_model(models)

        elif sub == "2" and can_install:
            _do_install(provider_name, fetch_fn)
            refresh = fetch_fn()

        elif sub == ("3" if can_install else "2") and can_remove:
            if not models:
                print("  No models to remove.")
                continue
            name = input("  Enter model name to remove: ").strip()
            if name:
                _do_remove(provider_name, name)
                refresh = fetch_fn()

        elif sub in [str(len(opts) - 2), str(2 + can_install + can_remove)]:
            refresh = fetch_fn()

        elif sub in [str(len(opts) - 1), str(3 + can_install + can_remove)]:
            manual = input("  Model name: ").strip()
            if manual:
                return manual
            continue

        elif sub in [str(len(opts)), str(4 + can_install + can_remove)]:
            return None  # go back

        else:
            print("  Invalid choice.")


def _do_install(provider_name, fetch_fn):
    if provider_name == "Ollama":
        name = input("  Model name to pull (e.g. llama3.2): ").strip()
        if name:
            ollama_pull(name)
    elif provider_name == "LM Studio":
        print("  Use the LM Studio GUI to download models (Ctrl+Shift+M).")
        input("  Press Enter when done...")
    elif provider_name == "AirLLM":
        print(f"\n  How to get the model?")
        print("    1. Browse to a local folder")
        print("    2. Enter HuggingFace repo ID")
        print("    3. Enter a download URL")
        sub2 = input("  Choice: ").strip()
        if sub2 == "1":
            path = browse_folder()
            if path and os.path.isdir(path):
                return path
        elif sub2 in ("2", "3"):
            ref = input("  Enter reference: ").strip()
            if ref:
                return ref
        return None


def _do_remove(provider_name, name):
    if provider_name == "Ollama":
        confirm = input(f"  Remove '{name}'? (y/n): ").strip().lower()
        if confirm == 'y':
            ollama_remove(name)
    elif provider_name == "AirLLM":
        confirm = input(f"  Delete folder '{name}'? This cannot be undone! (y/n): ").strip().lower()
        if confirm == 'y':
            if os.path.isdir(name):
                shutil.rmtree(name, ignore_errors=True)
                print(f"  Deleted {name}")
            else:
                print("  Not a valid directory path.")


def airllm_refresh():
    """For AirLLM: list recent model folders from default locations."""
    dirs = []
    home = os.path.expanduser("~")
    candidates = [
        os.path.join(home, "models"),
        os.path.join(home, ".cache", "huggingface", "hub"),
    ]

    no_model = frozenset({
        "command_logs", "assistant_core", "browser_screenshots",
        "__pycache__", ".git", ".idea", ".vscode", "node_modules",
        "venv", ".venv", "env", ".env",
    })

    for base in candidates:
        if not os.path.isdir(base):
            continue
        try:
            for entry in sorted(os.listdir(base)):
                full = os.path.join(base, entry)
                if not os.path.isdir(full) or entry.startswith("."):
                    continue
                if _is_model_dir(full):
                    dirs.append(full)
        except PermissionError:
            pass

    return sorted(dirs)


def _is_model_dir(path):
    """Check if a directory looks like a model folder."""
    indicators = [
        "config.json",
        "model.safetensors.index.json",
        "pytorch_model.bin.index.json",
    ]
    for ind in indicators:
        if os.path.isfile(os.path.join(path, ind)):
            return True
    # Check for safetensors shards (split layers by airllm)
    try:
        for f in os.listdir(path):
            if f.endswith(".safetensors"):
                return True
    except PermissionError:
        pass
    return False


PROVIDER_CONFIGS = {
    "3": {
        "name": "OpenAI",
        "base_url": "https://api.openai.com",
        "model_tip": "Tip: Copy-paste from https://platform.openai.com/docs/models",
        "example": "gpt-4o",
    },
    "4": {
        "name": "DeepSeek",
        "base_url": "https://api.deepseek.com",
        "model_tip": "Tip: Copy-paste from https://platform.deepseek.com/api-docs",
        "example": "deepseek-chat",
    },
    "5": {
        "name": "OpenRouter",
        "base_url": "https://openrouter.ai/api",
        "model_tip": "Tip: Browse available models at https://openrouter.ai/models and copy-paste the model ID",
        "example": "anthropic/claude-sonnet-4",
        "force_manual": True,
    },
    "6": {
        "name": "HuggingFace",
        "base_url": "https://api-inference.huggingface.co",
        "model_tip": "Tip: Browse models at https://huggingface.co/models and copy-paste the model ID (e.g. meta-llama/Llama-3.3-70B-Instruct)",
        "example": "meta-llama/Llama-3.3-70B-Instruct",
        "force_manual": True,
    },
}


def select_provider():
    while True:
        print("\nSelect AI Provider:")
        print("  1. Ollama (local)")
        print("  2. LM Studio (local)")
        print("  3. OpenAI (API key)")
        print("  4. DeepSeek (API key)")
        print("  5. OpenRouter (API key)")
        print("  6. HuggingFace (API key)")
        print("  7. AirLLM (local large model — CPU/GPU offloading)")
        try:
            choice = input("Enter 1-7: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            sys.exit(0)

        if choice == "1":
            print("\n--- Ollama ---")
            models = get_ollama_models()
            if not models and not _ollama_reachable():
                print("Ollama not reachable. Start it first (ollama serve).")
                continue
            selected_model = local_model_menu("Ollama", models or [], get_ollama_models)
            if selected_model is None:
                continue
            provider_type = "ollama"
            api_key = None
            base_url = None

        elif choice == "2":
            print("\n--- LM Studio ---")
            models = get_lmstudio_models()
            selected_model = local_model_menu(
                "LM Studio", models or [], get_lmstudio_models,
                can_install=False, can_remove=False
            )
            if selected_model is None:
                continue
            provider_type = "lmstudio"
            api_key = None
            base_url = "http://localhost:1234"

        elif choice in PROVIDER_CONFIGS:
            cfg = PROVIDER_CONFIGS[choice]
            print(f"\n--- {cfg['name']} Setup ---")
            api_key = input(f"Enter {cfg['name']} API key: ").strip()
            if not api_key:
                print("API key is required.")
                continue

            base_url = cfg["base_url"]

            if cfg.get("force_manual"):
                print(f"\n{cfg['name']} requires you to enter the exact model name.")
                print(f"  {cfg['model_tip']}")
                print(f"  Example: {cfg['example']}")
                selected_model = input("Model name: ").strip()
                if not selected_model:
                    sys.exit(1)
            else:
                print(f"Fetching available models from {cfg['name']}...")
                models = get_api_models(base_url, api_key)
                if models:
                    print("Available models:")
                    for idx, m in enumerate(models):
                        print(f"  {idx+1}. {m}")
                    selected_model = pick_model(models)
                else:
                    print(f"Could not fetch models from {cfg['name']}.")
                    print(f"  {cfg['model_tip']}")
                    print(f"  Example: {cfg['example']}")
                    selected_model = input("Model name: ").strip()
                    if not selected_model:
                        sys.exit(1)

            provider_type = "api"

        elif choice == "7":
            print("\n--- AirLLM: Local Large Model Setup ---")
            print("AirLLM runs large models (70B+) on consumer hardware by")
            print("loading one layer at a time into GPU/CPU — no massive VRAM needed.")
            print("Requires: pip install airllm (bitsandbytes optional for 4bit)")

            models = airllm_refresh()
            selected_model = local_model_menu("AirLLM", models, airllm_refresh)
            if selected_model is None:
                continue
            if not selected_model:
                sys.exit(1)

            print(f"\nModel location: {selected_model}")

            print("\nSelect device:")
            print("  1. CUDA GPU (recommended)")
            print("  2. CPU only (very slow)")
            dev_choice = input("Enter 1 or 2 [1]: ").strip() or "1"
            device = "cuda:0" if dev_choice == "1" else "cpu"

            seq_input = input("Max sequence length [2048]: ").strip()
            max_seq_len = int(seq_input) if seq_input else 2048

            print("\nCompression (requires bitsandbytes):")
            print("  1. None (full precision)")
            print("  2. 4-bit (recommended for 70B+ models)")
            comp_choice = input("Enter 1 or 2 [2]: ").strip() or "2"
            compression = "4bit" if comp_choice == "2" else None

            hf_token = input("HuggingFace token for gated models (or press Enter): ").strip() or None
            provider_type = "airllm"
            api_key = hf_token
            base_url = None

        else:
            print("Invalid choice. Enter a number between 1 and 7.")
            continue

        break

    print(f"\nSelected model: {selected_model}")
    config = {
        "provider_type": provider_type,
        "model": selected_model,
        "api_key": api_key,
        "base_url": base_url,
    }
    if provider_type == "airllm":
        config["airllm_device"] = device
        config["airllm_max_seq_len"] = max_seq_len
        config["airllm_compression"] = compression
    return config


def _ollama_reachable():
    try:
        resp = requests.get("http://localhost:11434/api/tags", timeout=2)
        return resp.status_code == 200
    except Exception:
        return False
