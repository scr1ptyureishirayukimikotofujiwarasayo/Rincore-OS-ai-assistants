# Model Recommendations for macOS Automation

Small models (3B-14B parameters) are **not recommended** for OS-level automation tasks. They tend to:

- Generate incorrect or malformed shell commands
- Misunderstand file paths and permissions (especially macOS's `~/Library`, `/Applications`, .app bundles)
- Fail to follow multi-step instructions reliably
- Hallucinate flags, arguments, or package names (e.g., `brew` formulas)

For reliable macOS automation, you need a model that can reason step by step, understand system internals, and generate precise commands.

## Recommended Approach: Cloud Models

Cloud-hosted models are the most practical option for most users. They run on powerful remote hardware, require no local GPU, and give you access to the largest, most capable models.

**Important:** Any cloud model — even a small one like Claude Haiku 3.5 or GPT-4o-mini — will generally outperform a much larger local model on OS automation tasks. This is because cloud models run at full precision (no quantization loss), benefit from continuous server-side optimizations, and are backed by infrastructure that allows them to dedicate more compute per token. A quantized 70B model running locally at Q4 will often be less reliable than a cloud-based 8B model running at full float precision.

| Model | Provider | Parameters | Why |
|-------|----------|-----------|-----|
| **Claude Sonnet 4** | [Anthropic](https://claude.ai) | Unknown | Excellent at shell commands, path reasoning, and tool use |
| **GPT-4o** | [OpenAI](https://openai.com) | Unknown | Strong general reasoning, good at command generation |
| **DeepSeek-V3** | [DeepSeek](https://deepseek.com) | ~660B | Very large, competitive with top closed models |
| **Qwen3-Coder-480B** | [Alibaba Cloud](https://huggingface.co/Qwen) | 480B | Specialized for coding/commands, excellent output |
| **Claude Haiku 3.5** | [Anthropic](https://claude.ai) | Unknown | Fast, cheap, and surprisingly good for smaller automation tasks |

**Where to get API keys:**
- https://openrouter.ai — unified access to many models, pay-as-you-go
- https://openai.com — GPT-4o
- https://claude.ai — Claude models
- https://deepseek.com — DeepSeek models

## Alternative: Local Large Models (High VRAM Required)

If you have a powerful GPU (24GB+ VRAM), you can run larger models locally via Ollama or LM Studio.

| Model | Size | Min VRAM | Notes |
|-------|------|----------|-------|
| **Qwen3-Coder-32B** (Q4) | ~18GB | 24GB | Best local option for macOS automation |
| **DeepSeek-Coder-V2-Lite** (Q4) | ~16GB | 20GB | Good alternative |
| **Llama 3.3-70B** (Q4) | ~40GB | 48GB | Excellent if you have the hardware |
| **Qwen3-Coder-480B** (Q4) | ~270GB | 320GB+ | Requires multi-GPU setup |

Quantization (Q4, Q8) reduces model size and VRAM requirements with minimal quality loss.

### What You Can Run by VRAM Tier

| VRAM | What's Practical |
|------|-----------------|
| 8-12 GB | 7B-14B models (limited capability, use for simple tasks only) |
| 16-24 GB | 14B-32B models (usable for basic automation with careful prompting) |
| 24-48 GB | 32B-70B models (good quality, recommended minimum for OS automation) |
| 48 GB+ | 70B+ models (excellent, near cloud-model quality) |

## macOS-Specific Considerations

macOS has some unique characteristics the AI needs to handle:

- **Package manager**: Homebrew (`brew`) is the standard; the AI should prefer `brew install` over manual downloads
- **File paths**: `/Users/` instead of `/home/`, `~/Library/` for app data, `.app` bundles in `/Applications/`
- **Shell**: zsh is the default shell since macOS Catalina; bash 3.2 is also available but older
- **Python**: macOS ships with Python 3; use `python3` or `python` (depends on setup)
- **Permissions**: Gatekeeper, SIP (System Integrity Protection), and TCC (privacy) can block automation
- **Browser automation**: Playwright works on macOS; Chromium may require first-run permission grants
- **pyautogui on macOS**: Requires Accessibility permissions in System Settings for mouse/keyboard control

## Why Size Matters for OS Automation

OS automation is fundamentally different from casual chat or text generation:

1. **Command precision** — A single wrong flag can delete files, break services, or corrupt data
2. **Multi-step reasoning** — Installing software involves Homebrew taps, dependency resolution, and PATH configuration
3. **Error recovery** — The model must read error output and adjust its approach
4. **System awareness** — Understanding paths, permissions, environment variables, and OS-specific behavior

Larger models (70B+) handle all of these significantly better than small models. If you're serious about macOS automation, invest in a cloud API — it's cheaper than buying a multi-GPU workstation and works on any machine.
