import os
import subprocess
import sys
import tempfile
from datetime import datetime
from assistant_core.platform_utils import (
    get_shell, get_script_handler, get_npm_cmd, get_os_name,
)

_working_dir = None
_log_counter = 0


def ensure_log_dir():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "command_logs")
    os.makedirs(path, exist_ok=True)
    return path


def clear_command_logs():
    log_dir = ensure_log_dir()
    count = 0
    for f in os.listdir(log_dir):
        if f.endswith(".log"):
            try:
                os.remove(os.path.join(log_dir, f))
                count += 1
            except Exception:
                pass
    return count


def get_log_files(limit=10):
    log_dir = ensure_log_dir()
    files = sorted([f for f in os.listdir(log_dir) if f.endswith(".log")], reverse=True)
    return [os.path.join(log_dir, f) for f in files[:limit]]


def read_recent_logs(limit=5):
    files = get_log_files(limit)
    if not files:
        return "No logs found."
    parts = []
    for f in reversed(files):
        try:
            with open(f, "r", encoding="utf-8") as fh:
                parts.append(fh.read().rstrip())
        except Exception as e:
            parts.append(f"[Error reading {os.path.basename(f)}: {e}]")
    return "\n---\n".join(parts)


def get_recent_failures(limit=5):
    log_dir = ensure_log_dir()
    files = sorted([f for f in os.listdir(log_dir) if f.endswith(".log")], reverse=True)
    failures = []
    for f in files:
        filepath = os.path.join(log_dir, f)
        try:
            with open(filepath, "r", encoding="utf-8") as fh:
                content = fh.read()
            if "FAILED" in content:
                failures.append(content)
                if len(failures) >= limit:
                    break
        except Exception:
            pass
    return failures


def log_command(shell_type, command, output, exit_code):
    global _log_counter
    log_dir = ensure_log_dir()
    ts = datetime.now()
    _log_counter += 1
    filename = f"cmd_{ts.strftime('%Y%m%d_%H%M%S')}_{_log_counter:04d}.log"
    filepath = os.path.join(log_dir, filename)
    status = "SUCCESS" if exit_code == 0 else "FAILED"
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(f"Timestamp : {ts.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Shell     : {shell_type}\n")
        f.write(f"Exit Code : {exit_code}\n")
        f.write(f"Status    : {status}\n")
        f.write(f"Command   : {command}\n")
        f.write(f"{'='*60}\n")
        f.write(f"Output:\n{output}\n")


def get_cwd():
    return _working_dir or os.getcwd()


def set_working_dir(path):
    global _working_dir
    expanded = os.path.abspath(os.path.expandvars(os.path.expanduser(path)))
    if os.path.isdir(expanded):
        _working_dir = expanded
        return f"Working directory set to {expanded}", True
    return f"Directory not found: {expanded}", False


def execute_shell(command, shell_cmd, cwd=None):
    try:
        result = subprocess.run(
            shell_cmd + [command],
            capture_output=True, text=True, timeout=30,
            cwd=cwd or get_cwd()
        )
        return result
    except subprocess.TimeoutExpired:
        class MockResult:
            def __init__(self):
                self.returncode = 1
                self.stdout = ""
                self.stderr = "Command timed out after 30 seconds."
        return MockResult()
    except Exception as e:
        class MockResult:
            def __init__(self):
                self.returncode = 1
                self.stdout = ""
                self.stderr = f"Error: {e}"
        return MockResult()


def run_os_command(command, shell_type="auto", is_admin=False, cwd=None):
    sh = get_shell()
    st = shell_type.lower()
    if st in ("powershell", "cmd") and sh["name"] == "powershell":
        result = execute_shell(command, sh["cmd"] if st == "powershell" else sh["alt_cmd"], cwd)
    elif st in ("bash", "sh") or (st == "auto" and sh["name"] != "powershell"):
        result = execute_shell(command, sh["cmd"], cwd)
    elif st == "cmd":
        result = execute_shell(command, sh.get("alt_cmd", sh["cmd"]), cwd)
    else:
        result = execute_shell(command, sh["cmd"], cwd)
    exit_code = result.returncode
    output = result.stdout + result.stderr
    label = sh["shell_name"] if st == "auto" else st
    log_command(label, command, output, exit_code)
    return output, exit_code


def confirm_action(command, shell_type):
    print(f"\n[!] Command to execute ({shell_type}):")
    print(f"    {command}")
    confirm = input("Execute? (y/n): ").strip().lower()
    return confirm == 'y'


# --- File operations ---

def read_file(path):
    expanded = os.path.abspath(os.path.expandvars(os.path.expanduser(path)))
    if not os.path.exists(expanded):
        return f"File not found: {expanded}", False
    try:
        with open(expanded, "r", encoding="utf-8") as f:
            content = f.read()
        return content, True
    except Exception as e:
        return f"Error reading file: {e}", False


def write_file(path, content):
    expanded = os.path.abspath(os.path.expandvars(os.path.expanduser(path)))
    try:
        os.makedirs(os.path.dirname(expanded), exist_ok=True)
        with open(expanded, "w", encoding="utf-8") as f:
            f.write(content)
        return f"Written to {expanded}", True
    except Exception as e:
        return f"Error writing file: {e}", False


# --- Code execution ---

LANGUAGE_CONFIG = {
    "python":     {"ext": ".py",   "cmd": ["python"]},
    "py":         {"ext": ".py",   "cmd": ["python"]},
    "javascript": {"ext": ".js",   "cmd": ["node"]},
    "js":         {"ext": ".js",   "cmd": ["node"]},
    "typescript": {"ext": ".ts",   "cmd": ["npx", "tsx"]},
    "ts":         {"ext": ".ts",   "cmd": ["npx", "tsx"]},
    "html":       {"ext": ".html", "cmd": None},
    "css":        {"ext": ".css",  "cmd": None},
    "json":       {"ext": ".json", "cmd": None},
    "xml":        {"ext": ".xml",  "cmd": None},
    "yaml":       {"ext": ".yaml", "cmd": None},
    "yml":        {"ext": ".yml",  "cmd": None},
    "markdown":   {"ext": ".md",   "cmd": None},
    "md":         {"ext": ".md",   "cmd": None},
    "sql":        {"ext": ".sql",  "cmd": None},
    "rust":       {"ext": ".rs",   "cmd": ["rustc"]},
    "go":         {"ext": ".go",   "cmd": ["go", "run"]},
    "ruby":       {"ext": ".rb",   "cmd": ["ruby"]},
    "php":        {"ext": ".php",  "cmd": ["php"]},
}


def run_code(code, language, cwd=None):
    lang = LANGUAGE_CONFIG.get(language.lower())
    if not lang:
        return f"No handler for language: {language}", -1
    if lang["cmd"] is None:
        return (f"Code written but not executed. "
                f"Save it to a file with the .{lang['ext'].lstrip('.')} extension.", 0)

    suffix = lang["ext"]
    prefix = "code_exec_"
    tmp = tempfile.NamedTemporaryFile(mode="w", suffix=suffix, prefix=prefix,
                                       delete=False, encoding="utf-8")
    tmp.write(code)
    tmp.close()
    try:
        cmd = lang["cmd"] + [tmp.name]
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=30,
            cwd=cwd or get_cwd()
        )
        output = result.stdout + result.stderr
        exit_code = result.returncode
        log_command(language, f"{' '.join(cmd)}", output, exit_code)
        return output, exit_code
    except subprocess.TimeoutExpired:
        return "Code execution timed out after 30 seconds.", -1
    except FileNotFoundError:
        return (f"Runtime not found for '{language}'. "
                f"Make sure {'/'.join(lang['cmd'])} is installed and on PATH.", -1)
    except Exception as e:
        return f"Error: {e}", -1
    finally:
        try:
            os.unlink(tmp.name)
        except Exception:
            pass


def run_script(path, cwd=None):
    expanded = os.path.abspath(os.path.expandvars(os.path.expanduser(path)))
    if not os.path.exists(expanded):
        return f"File not found: {expanded}", -1
    ext = os.path.splitext(expanded)[1].lower()
    handler = get_script_handler(ext)
    if not handler:
        return f"No handler for extension: {ext}", -1
    cmd = [part.replace("{path}", expanded) for part in handler]
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=60,
            cwd=cwd or get_cwd()
        )
        output = result.stdout + result.stderr
        exit_code = result.returncode
        log_command("script", f"{' '.join(cmd)}", output, exit_code)
        return output, exit_code
    except subprocess.TimeoutExpired:
        return "Script execution timed out after 60 seconds.", -1
    except FileNotFoundError:
        return f"Runtime not found for {ext} files. Is it installed and on PATH?", -1
    except Exception as e:
        return f"Error: {e}", -1


def run_npm(args, cwd=None):
    try:
        result = subprocess.run(
            get_npm_cmd(args),
            capture_output=True, text=True, timeout=60,
            cwd=cwd or get_cwd()
        )
        output = result.stdout + result.stderr
        exit_code = result.returncode
        log_command("npm", f"npm {args}", output, exit_code)
        return output, exit_code
    except subprocess.TimeoutExpired:
        return "npm command timed out after 60 seconds.", -1
    except Exception as e:
        return f"Error: {e}", -1


def run_pip(args, cwd=None):
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip"] + args.split(),
            capture_output=True, text=True, timeout=120,
            cwd=cwd or get_cwd()
        )
        output = result.stdout + result.stderr
        exit_code = result.returncode
        log_command("pip", f"pip {args}", output, exit_code)
        return output, exit_code
    except subprocess.TimeoutExpired:
        return "pip command timed out after 120 seconds.", -1
    except Exception as e:
        return f"Error: {e}", -1


# --- Error logging ---

_error_counter = 0


def ensure_error_log_dir():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "error_logs")
    os.makedirs(path, exist_ok=True)
    return path


def log_error(traceback_text, last_input=""):
    global _error_counter
    log_dir = ensure_error_log_dir()
    ts = datetime.now()
    _error_counter += 1
    filename = f"err_{ts.strftime('%Y%m%d_%H%M%S')}_{_error_counter:04d}.log"
    filepath = os.path.join(log_dir, filename)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(f"Timestamp  : {ts.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"{'='*60}\n")
        f.write(traceback_text)
        if last_input:
            f.write(f"\n{'='*60}\n")
            f.write(f"Last Input : {last_input}\n")


def read_error_logs(limit=5):
    log_dir = ensure_error_log_dir()
    files = sorted(
        [f for f in os.listdir(log_dir) if f.endswith(".log")], reverse=True
    )
    if not files:
        return "No error logs found."
    parts = []
    for f in reversed(files[:limit]):
        try:
            with open(os.path.join(log_dir, f), "r", encoding="utf-8") as fh:
                parts.append(fh.read().rstrip())
        except Exception as e:
            parts.append(f"[Error reading {f}: {e}]")
    return "\n---\n".join(parts)


def clear_error_logs():
    log_dir = ensure_error_log_dir()
    count = 0
    for f in os.listdir(log_dir):
        if f.endswith(".log"):
            try:
                os.remove(os.path.join(log_dir, f))
                count += 1
            except Exception:
                pass
    return count

