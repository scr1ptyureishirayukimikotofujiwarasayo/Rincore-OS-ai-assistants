import os
import sys
import time
import subprocess
from datetime import datetime
from assistant_core.platform_utils import get_os, open_program_args

try:
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.05
except ImportError:
    pyautogui = None

_SCREENSHOT_DIR = "autotask_screenshots"


class AutoTaskAgent:
    def __init__(self):
        self._process = None
        self._window_title = ""
        self._last_result = ""

    def check_deps(self):
        if pyautogui is None:
            return "pyautogui not installed. Run: pip install pyautogui pygetwindow"
        return None

    def _get_platform(self):
        return get_os()

    def open_program(self, target):
        plat = self._get_platform()
        try:
            if plat == "windows":
                self._process = subprocess.Popen(
                    open_program_args(target),
                    shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
            elif plat == "macos":
                self._process = subprocess.Popen(
                    open_program_args(target),
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
            else:
                self._process = subprocess.Popen(
                    target, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
            time.sleep(2)
            self._last_result = f"Opened: {target} (PID: {self._process.pid})"
            return self._last_result
        except Exception as e:
            return f"Failed to open '{target}': {e}"

    def find_window(self, title):
        try:
            import pygetwindow as gw
            wins = gw.getWindowsWithTitle(title)
            if not wins:
                return f"No window found with title containing '{title}'"
            win = wins[0]
            try:
                win.activate()
            except Exception:
                try:
                    win.minimize()
                    win.restore()
                except Exception:
                    pass
            self._window_title = title
            x, y, w, h = win.left, win.top, win.width, win.height
            self._last_result = f"Window '{title}' — position: ({x},{y}) size: {w}x{h}"
            return self._last_result
        except ImportError:
            return "pygetwindow not installed. Run: pip install pygetwindow"
        except Exception as e:
            return f"Window error: {e}"

    def window_list(self):
        try:
            import pygetwindow as gw
            wins = gw.getAllTitles()
            wins = [w for w in wins if w.strip()]
            if not wins:
                return "No visible windows."
            result = "\n".join(f"  {i+1}. {w}" for i, w in enumerate(wins[:30]))
            self._last_result = f"Open windows:\n{result}"
            return self._last_result
        except ImportError:
            return "pygetwindow not installed. Run: pip install pygetwindow"
        except Exception as e:
            return f"Window list error: {e}"

    def move_mouse(self, x, y, duration=0.3):
        try:
            pyautogui.moveTo(int(x), int(y), duration=duration)
            self._last_result = f"Mouse moved to ({x}, {y})"
            return self._last_result
        except Exception as e:
            return f"Move error: {e}"

    def click(self, x=None, y=None, button="left", clicks=1):
        try:
            if x is not None and y is not None:
                pyautogui.click(int(x), int(y), button=button, clicks=int(clicks))
                self._last_result = f"Clicked ({button}) at ({x}, {y})"
            else:
                pyautogui.click(button=button, clicks=int(clicks))
                x, y = pyautogui.position()
                self._last_result = f"Clicked ({button}) at current position ({x}, {y})"
            return self._last_result
        except Exception as e:
            return f"Click error: {e}"

    def double_click(self, x=None, y=None):
        return self.click(x, y, clicks=2)

    def right_click(self, x=None, y=None):
        return self.click(x, y, button="right")

    def drag(self, x1, y1, x2, y2, duration=0.5):
        try:
            pyautogui.moveTo(int(x1), int(y1))
            pyautogui.drag(int(x2), int(y2), duration=duration)
            self._last_result = f"Dragged from ({x1},{y1}) to ({x2},{y2})"
            return self._last_result
        except Exception as e:
            return f"Drag error: {e}"

    def type_text(self, text):
        try:
            pyautogui.typewrite(text, interval=0.02)
            self._last_result = f"Typed: {text[:80]}{'...' if len(text) > 80 else ''}"
            return self._last_result
        except Exception as e:
            return f"Type error: {e}"

    def press_key(self, key):
        try:
            key_map = {
                "enter": "enter", "return": "enter", "esc": "escape",
                "tab": "tab", "space": "space", "backspace": "backspace",
                "delete": "delete", "up": "up", "down": "down",
                "left": "left", "right": "right", "home": "home",
                "end": "end", "pageup": "pageup", "pagedown": "pagedown",
                "f1": "f1", "f2": "f2", "f3": "f3", "f4": "f4",
                "f5": "f5", "f6": "f6", "f7": "f7", "f8": "f8",
                "f9": "f9", "f10": "f10", "f11": "f11", "f12": "f12",
            }
            k = key_map.get(key.lower().strip(), key.lower().strip())
            pyautogui.press(k)
            self._last_result = f"Pressed key: {k}"
            return self._last_result
        except Exception as e:
            return f"Key press error: {e}"

    def hotkey(self, keys_str):
        try:
            keys = keys_str.strip().split()
            if len(keys) < 2:
                return "Usage: hotkey <key1> <key2> [...] (e.g. ctrl c, alt tab)"
            pyautogui.hotkey(*keys)
            self._last_result = f"Hotkey: {'+'.join(keys)}"
            return self._last_result
        except Exception as e:
            return f"Hotkey error: {e}"

    def scroll(self, amount):
        try:
            pyautogui.scroll(int(amount))
            direction = "up" if int(amount) > 0 else "down"
            self._last_result = f"Scrolled {direction} {abs(int(amount))} clicks"
            return self._last_result
        except Exception as e:
            return f"Scroll error: {e}"

    def screenshot(self, path=None):
        os.makedirs(_SCREENSHOT_DIR, exist_ok=True)
        if not path:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = os.path.join(_SCREENSHOT_DIR, f"autotask_{ts}.png")
        try:
            img = pyautogui.screenshot()
            img.save(path)
            self._last_result = f"Screenshot saved: {path} ({img.size[0]}x{img.size[1]})"
            return self._last_result
        except Exception as e:
            return f"Screenshot error: {e}"

    def locate(self, image_path, confidence=0.8):
        try:
            if not os.path.isfile(image_path):
                return f"Image not found: {image_path}"
            pos = pyautogui.locateOnScreen(image_path, confidence=float(confidence))
            if pos:
                cx = pos.left + pos.width // 2
                cy = pos.top + pos.height // 2
                self._last_result = f"Found '{image_path}' at ({pos.left},{pos.top}) size {pos.width}x{pos.height}, center ({cx},{cy})"
                return self._last_result
            else:
                return f"Image '{image_path}' not found on screen."
        except Exception as e:
            return f"Locate error: {e}"

    def locate_all(self, image_path, confidence=0.8):
        try:
            if not os.path.isfile(image_path):
                return f"Image not found: {image_path}"
            positions = list(pyautogui.locateAllOnScreen(image_path, confidence=float(confidence)))
            if positions:
                lines = [f"  {i+1}. ({p.left},{p.top}) {p.width}x{p.height}" for i, p in enumerate(positions[:10])]
                self._last_result = f"Found {len(positions)} instance(s) of '{image_path}':\n" + "\n".join(lines)
                return self._last_result
            else:
                return f"Image '{image_path}' not found on screen."
        except Exception as e:
            return f"Locate all error: {e}"

    def get_position(self):
        try:
            x, y = pyautogui.position()
            self._last_result = f"Mouse position: ({x}, {y})"
            return self._last_result
        except Exception as e:
            return f"Position error: {e}"

    def resolution(self):
        try:
            w, h = pyautogui.size()
            self._last_result = f"Screen resolution: {w}x{h}"
            return self._last_result
        except Exception as e:
            return f"Resolution error: {e}"

    def wait(self, ms):
        time.sleep(int(ms) / 1000)
        return f"Waited {ms}ms"

    def close_program(self):
        if self._process:
            try:
                self._process.terminate()
                self._process = None
                self._last_result = "Program terminated."
                return self._last_result
            except Exception as e:
                return f"Terminate error: {e}"
        return "No program to close."


def process_autotask_command(agent, cmd_line):
    if not agent:
        return "AutoTask agent not initialized."
    deps = agent.check_deps()
    if deps:
        return deps
    parts = cmd_line.strip().split(maxsplit=1)
    if not parts:
        return "Usage: <action> [args...]"
    action = parts[0].lower()
    args = parts[1] if len(parts) > 1 else ""

    handlers = {
        "open": lambda: agent.open_program(args.strip()),
        "launch": lambda: agent.open_program(args.strip()),
        "find": lambda: agent.find_window(args.strip()),
        "window": lambda: agent.find_window(args.strip()),
        "windows": lambda: agent.window_list(),
        "window-list": lambda: agent.window_list(),
        "move": lambda: agent.move_mouse(*map(float, args.split())),
        "click": lambda: agent.click(*map(float, args.split())) if args.strip() else agent.click(),
        "doubleclick": lambda: agent.double_click(*map(float, args.split())) if args.strip() else agent.double_click(),
        "rightclick": lambda: agent.right_click(*map(float, args.split())) if args.strip() else agent.right_click(),
        "drag": lambda: agent.drag(*map(float, args.split())),
        "type": lambda: agent.type_text(args),
        "press": lambda: agent.press_key(args.strip()),
        "key": lambda: agent.press_key(args.strip()),
        "hotkey": lambda: agent.hotkey(args),
        "scroll": lambda: agent.scroll(args.strip()),
        "screenshot": lambda: agent.screenshot(args.strip() or None),
        "locate": lambda: agent.locate(*(args.split())),
        "locateall": lambda: agent.locate_all(*(args.split())),
        "pos": lambda: agent.get_position(),
        "position": lambda: agent.get_position(),
        "resolution": lambda: agent.resolution(),
        "res": lambda: agent.resolution(),
        "wait": lambda: agent.wait(args.strip()),
        "sleep": lambda: agent.wait(args.strip()),
        "close": lambda: agent.close_program(),
        "exit": lambda: agent.close_program(),
    }
    handler = handlers.get(action)
    if not handler:
        actions_list = ", ".join(sorted(handlers))
        return f"Unknown action: {action}. Available: {actions_list}"
    try:
        return handler()
    except Exception as e:
        return f"Error executing '{action}': {e}"
