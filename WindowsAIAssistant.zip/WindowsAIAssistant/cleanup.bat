@echo off
setlocal
set "SCRIPT_DIR=%~dp0"

echo ============================================
echo   Windows AI Assistant - Log Cleanup
echo ============================================
echo.

set /a COUNT=0

echo [1/2] Clearing command logs...
if exist "%SCRIPT_DIR%command_logs\*.log" (
    for %%f in ("%SCRIPT_DIR%command_logs\*.log") do (
        del /q "%%f" 2>nul
        set /a COUNT+=1
    )
    echo   Done - cleared command logs.
) else (
    echo   No command logs to clear.
)

echo [2/2] Clearing error logs...
if exist "%SCRIPT_DIR%error_logs\*.log" (
    for %%f in ("%SCRIPT_DIR%error_logs\*.log") do (
        del /q "%%f" 2>nul
        set /a COUNT+=1
    )
    echo   Done - cleared error logs.
) else (
    echo   No error logs to clear.
)

echo.
echo ============================================
echo   Cleanup complete. Project is GitHub-ready.
echo ============================================
pause
