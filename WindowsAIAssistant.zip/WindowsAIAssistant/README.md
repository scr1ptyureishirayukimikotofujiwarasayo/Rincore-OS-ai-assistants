# Windows OS AI Assistant

An AI-powered assistant for Windows that can execute PowerShell and CMD commands, write and run code, build projects, search the web, automate desktop programs, control a web browser, self-diagnose and fix errors, and answer questions — using local or cloud AI models.

## Features

- **Multiple AI backends**: Ollama (local), LM Studio (local), or API-based (OpenAI, Anthropic, OpenRouter, DeepSeek, HuggingFace, AirLLM)
- **System command execution**: Run PowerShell (`!ps`) or CMD (`!cmd`) commands directly
- **File operations**: Read (`!read`) and write (`!write`) files directly
- **Code execution**: Run code in Python, JavaScript, TypeScript, Rust, Go, Ruby, PHP, and more
- **Package management**: Install packages with `!pip` and `!npm`
- **AI-driven code proposals**: The AI outputs code blocks for review, run, or save
- **Auto-execute mode** (`/auto`): Automatically runs AI code blocks without confirmation
- **Build mode** (`/build <desc>`): Autonomous multi-step build workflow
- **Fully autonomous mode** (`/fullyauto <desc>`): AI has full control of ALL tools — search, browse, desktop automation, test/automate programs, and code execution — chaining actions until the goal is done
- **Chat mode** (`/chat [topic]`): Pure conversation mode — no code, no tools, just talk
- **Web search**: Automatic or manual web search via DuckDuckGo
- **Self-updating search engine**: Auto-updates the `ddgs` library from PyPI
- **Browser automation** (`/browser`, `!browse`): Control Chromium via Playwright — navigate, click, type, extract, screenshots
- **Desktop automation** (`/autotask`, `!autotask`): Control mouse, keyboard, and windows via pyautogui — open programs, click, type, take screenshots, locate images
- **Program testing** (`/test <program>`): AI opens a program, tests functionality, reports results
- **Program automation** (`/automate <program> <task>`): AI opens a program and performs a specific task (e.g., `/automate opencode create a flask app`)
- **Structured planning** (`/plan <goal>`): AI breaks tasks into numbered steps and works through them with progress tracking
- **Self-fixing** (`/reviewerrorlogs`, `/selffix`): AI diagnoses crash/error logs and auto-executes fixes
- **Anti-crash recovery**: Automatic crash logging, state reset, and restart — the assistant recovers instead of exiting
- **Admin mode toggle**: Flag commands as admin-level
- **Command logging**: Every command logged to `command_logs/` with structured files
- **Error logging**: All crashes and unhandled errors logged to `error_logs/`
- **Automatic error troubleshooting**: Failed commands auto-inject failure logs so the AI can diagnose root causes
- **Action review**: `/logs` and `/review` let the AI inspect past commands for mistakes
- **Cleanup**: `/cleanup` command and `cleanup.bat` clear all logs for GitHub-ready state
- **Conversation context management**: Auto-trims history to prevent model confusion

## Requirements

- Python 3.7+
- One of the following AI backends:
  - [Ollama](https://ollama.com) — run models locally
  - [LM Studio](https://lmstudio.ai) — run models locally
  - An API key from [OpenAI](https://openai.com), [Anthropic](https://claude.ai), [OpenRouter](https://openrouter.ai), [DeepSeek](https://deepseek.com), etc.

## Installation

```bash
pip install -r requirements.txt
python -m playwright install chromium
```

## Usage

```bash
python main.py
```

The assistant will guide you through:
1. **Admin mode** — choose whether commands should run with admin privileges
2. **AI provider** — select Ollama, LM Studio, or API key provider
3. **Model selection** — pick from available models
4. **Chat loop** — interact with the AI

### Chat Commands

| Command | Description |
|---------|-------------|
| `exit` | Exit the assistant |
| `/help`, `/?` | Show the in-app command list |
| `/chat [topic]` | Pure conversation mode — no code, no tools, just chat. `exit` to leave |
| `/search <query>` | Force a web search on any topic |
| `/toggle` | Enable/disable automatic web search |
| `/logs [N]` | Show the last N command logs and have the AI review them |
| `/clearcommandlogs` | Delete all command logs from `command_logs/` |
| `/clearerrorlogs` | Delete all error logs from `error_logs/` |
| `/cleanup` | Clear BOTH command and error logs (GitHub-ready). Also available as `cleanup.bat` |
| `/review` | Have the AI inspect recent commands for mistakes |
| `/reviewerrorlogs` | AI diagnoses crash/error logs AND auto-executes fix code |
| `/selffix` | Aggressive self-fixing — scans all error/failure logs, auto-diagnoses and auto-fixes across up to 5 turns |
| `/auto` | Toggle auto-execution — AI code blocks run without confirmation |
| `/build <desc>` | Auto-build mode — AI plans and executes a multi-step build autonomously |
| `/fullyauto <desc>` | Full autonomy — AI controls ALL tools (search, browse, autotask, test, automate, code) and chains them until `[DONE]` |
| `/browser [--visible] [url]` | Browser automation — AI controls Chromium via `[BROWSE: ...]` tokens |
| `/autotask [program]` | Desktop automation — AI controls mouse/keyboard/windows via `[AUTOTASK: ...]` tokens |
| `/test <program>` | Open a program and test its functionality automatically |
| `/automate <program> <task>` | Open a program and automate a specific task with it |
| `/sandbox [goal]` | Autonomous mode restricted to the current working directory |
| `/plan <goal>` | Structured plan mode — AI breaks goal into numbered steps with progress tracking |
| `/status` | Show current plan progress |
| `/changemodel` | Switch the active model for the current provider |
| `/mainmenu` | Reselect AI provider and start a fresh session |
| `/resetassistant` | Clear logs and wipe conversation history (keeps provider) |

### Direct Commands

| Command | Description |
|---------|-------------|
| `!ps <command>` | Execute a PowerShell command directly |
| `!cmd <command>` | Execute a CMD command directly |
| `!bash <command>` | Execute a Bash command directly |
| `!read <path>` | Read and display a file's contents |
| `!write <path>` | Write content to a file (paste content, end with `---EOF---`) |
| `!cd <dir>` | Change the working directory |
| `!run <script>` | Execute a script file by path |
| `!npm <args>` | Run npm commands (install, build, test, etc.) |
| `!pip <args>` | Run pip commands (install, uninstall, list, etc.) |
| `!browse <action>` | Direct browser command (go, click, type, extract, screenshot, etc.) |
| `!autotask <action>` | Direct desktop automation (open, click, type, press, locate, screenshot, etc.) |

### Supported Languages for Code Execution

Python (`py`), JavaScript (`js`), TypeScript (`ts`), Rust, Go, Ruby, PHP, HTML, CSS, JSON, XML, YAML, Markdown, SQL.

Runnable languages execute via temp files. Non-runnable languages (HTML, CSS, JSON, etc.) prompt you to save to a file.

### How AI Code Execution Works

1. Ask the AI to perform a task (e.g., *"create a flask web app"*)
2. The AI responds with code in language-labelled blocks: ```python, ```javascript, etc.
3. In normal mode, you **review and confirm** before code runs
4. In auto mode (`/auto` or `/build`), blocks execute automatically
5. The output is fed back to the AI for further discussion

### Automatic Error Troubleshooting

When any command or code execution fails, the system automatically pulls the last 3 failed command logs and injects them into the conversation as context for the AI. This allows the AI to:

- Trace the sequence of events that led to the failure
- Distinguish between root cause and downstream errors
- Propose targeted fixes based on the full command history

This happens transparently in all modes — normal, build, and fully autonomous. No manual `/review` needed for error diagnosis.

### Self-Fixing & Error Recovery

The assistant can diagnose and fix its own errors:

- **`/reviewerrorlogs`**: Reads crash/error logs, asks AI to diagnose the root cause and output a fix. The fix code is auto-executed.
- **`/selffix`**: Aggressive mode — scans all error logs AND command failure logs, then runs up to 5 autonomous turns of diagnose → auto-fix → verify.
- **Anti-crash**: If an unexpected error occurs mid-conversation, the error is logged to `error_logs/` and the assistant resets its state to continue running. If a fatal crash occurs, the main loop auto-restarts the assistant up to 3 times before safely exiting.
- **Error logs**: All crashes are stored in `error_logs/err_YYYYMMDD_HHMMSS_NNNN.log` for review.

### Desktop Automation

Control mouse, keyboard, and windows on your desktop via pyautogui:

- **`/autotask [program]`**: Enter desktop automation mode. AI controls the desktop via `[AUTOTASK: ...]` tokens.
- **`/test <program>`**: Opens a program and tests its core functionality — verifies it opens, tests menus, input, navigation, and reports issues.
- **`/automate <program> <task>`**: Opens a program and uses it to accomplish a specific task (e.g., `/automate opencode create a flask app`).
- **`!autotask <action>`**: One-off desktop command.

### Command & Error Logs

Every executed command is saved as an individual file in `command_logs/`:

```
cmd_20260515_045231_0003.log
  Timestamp : 2026-05-15 04:52:31
  Shell     : powershell
  Exit Code : 1
  Status    : FAILED
  Command   : Get-Service BrokenService
  ============================================================
  Output:
  Cannot find service
```

Error/crash logs are saved in `error_logs/`:

```
err_20260621_025009_0001.log
  Timestamp  : 2026-06-21 02:50:09
  ============================================================
  Traceback (most recent call last):
    ...
  TypeError: ...
```

Use `/logs 5` to show recent command logs, `/reviewerrorlogs` for error diagnosis, or `/cleanup` / `cleanup.bat` to clear all logs for a clean GitHub commit.

### Auto-Updating Search Engine

The search library (`ddgs`) is automatically checked against PyPI once per day. If a newer version is available, it's updated in the background before the next search. Disable this in `assistant_core/config.json`:

```json
{"auto_update": false, "auto_update_interval_hours": 24}
```

## Model Sources

| Source | Type | URL |
|--------|------|-----|
| Ollama | Local & Cloud | https://ollama.com |
| HuggingFace | Local & Cloud | https://huggingface.co |
| OpenRouter | Cloud (API key) | https://openrouter.ai |
| OpenAI | Cloud (API key) | https://openai.com |
| Anthropic | Cloud (API key) | https://claude.ai |
| DeepSeek | Cloud (API key) | https://deepseek.com |

## Important Notes

- The assistant has limited context memory (last ~30 turns). Excessive history can confuse the model.
- This is not a system repair tool. The AI can make mistakes. Always review commands before execution.
- For complex tasks, use larger models (e.g., Qwen3-Coder:480B) via cloud API if your local hardware is insufficient.
- Larger parameter models (more "brain size") generally produce better results for complex tasks.

## Project Structure

```
WindowsAIAssistant/
├── COMMANDS.txt              # Full command reference
├── README.md
├── LICENSE
├── MODEL_RECOMMENDATIONS.md
├── requirements.txt
├── .gitignore
├── cleanup.bat               # Clear all logs for GitHub-ready state
├── main.py                   # Entry point, chat loop, all mode handlers
├── executor.py               # Shell execution, file ops, code runner, logging
├── browser_agent.py          # Playwright-based browser automation
├── autotask_agent.py         # Desktop automation (pyautogui — mouse, keyboard, windows)
├── planner.py                # Structured task planner with step tracking
├── command_logs/             # Per-command execution logs
│   └── .gitkeep
├── error_logs/               # Crash and unhandled error logs
├── autotask_screenshots/     # Desktop automation screenshots
├── browser_screenshots/      # Browser automation screenshots
└── assistant_core/
    ├── __init__.py
    ├── config.json           # Auto-update settings
    ├── llm.py                # LLM API communication (Ollama, LM Studio, OpenAI, etc.)
    ├── provider.py           # AI provider selection wizard and model management
    ├── platform_utils.py     # OS detection, shell config, script handlers
    ├── search.py             # Low-level DuckDuckGo search
    ├── search_engine.py      # Search interface with auto-update
    └── update_manager.py     # PyPI version check and package update
```
