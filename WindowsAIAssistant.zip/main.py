import sys
import re
import os
import time
from dataclasses import dataclass, field

from assistant_core.provider import select_provider
from assistant_core.llm import generate_response
from assistant_core.search_engine import web_search, check_internet
from assistant_core.platform_utils import get_agent_name, get_shell_prompt_hint, get_os_name
from executor import (
    run_os_command, confirm_action, read_recent_logs,
    read_file, write_file, run_code, run_script,
    run_npm, run_pip, set_working_dir, get_cwd,
    get_recent_failures, clear_command_logs,
    log_error, read_error_logs, clear_error_logs,
)
from browser_agent import BrowserAgent, process_browse_command
from autotask_agent import AutoTaskAgent, process_autotask_command
from planner import planner as task_planner

SYSTEM_PROMPT = (
    f"You are {get_agent_name()}, an AI assistant specialized in software development on {get_os_name()}.\n\n"
    "## Core Rule: DO first, explain later\n"
    "- When the user asks you to perform a task, OUTPUT THE CODE OR COMMAND FIRST — do not lead with explanation.\n"
    "- Keep explanations short. One sentence before code is enough. Never write paragraphs before acting.\n"
    "- The user hired you to DO things, not explain things. Execute, then report.\n"
    "- If a task needs multiple steps, chain them together — do not pause to narrate each step.\n\n"
    "## Capabilities\n"
    "- Read and write files (!read, !write)\n"
    "- Execute code in Python, JavaScript, TypeScript, HTML, and more\n"
    "- Run scripts, npm, pip, and build tools (!run, !npm, !pip)\n"
    "- Manage projects and navigate directories (!cd)\n"
    "- Search the web for documentation and solutions\n"
    "- Control a web browser with !browse and /browser mode\n\n"
    "## Instructions\n"
    "- Output code in language-labeled code blocks: ```python, ```javascript, ```html, etc.\n"
    "- When creating a project, plan the file structure first\n"
    "- After errors, analyze the output and suggest fixes\n"
    "- Write clean, well-structured code with proper error handling\n\n"
    "## Output Format\n"
    "```python\n"
    "def hello():\n"
    '    print("Hello, World!")\n'
    "```\n\n"
    "## Example\n"
    "User: create a flask web app\n"
    "Assistant: I will create a basic Flask app. First, here is the main file:\n"
    "```python\n"
    "from flask import Flask\n"
    "app = Flask(__name__)\n\n"
    '@app.route("/")\n'
    "def home():\n"
    '    return "Hello, World!"\n\n'
    'if __name__ == "__main__":\n'
    "    app.run(debug=True)\n"
    "```\n"
    "Run it with: pip install flask && python app.py\n\n"
    "## Guidelines\n"
    f"{get_shell_prompt_hint()}\n"
    "- Use !pip install before importing new packages\n"
    "- When a build fails, diagnose the error and provide a fix\n"
    "- Think step by step before each response\n"
    "- If web search results are provided, reason through them before answering\n\n"
    "## Command Logs\n"
    "- All executed commands are logged to command_logs/\n"
    "- When a command fails, the system automatically attaches recent failure logs "
    "to help you diagnose the root cause\n"
    "- Use the failure logs to trace what went wrong and propose targeted fixes"
)

_HELP_TEXT = (
    "Commands: /help, /search <q>, /toggle, /logs [N], /clearcommandlogs, /review, /reviewerrorlogs, /clearerrorlogs, /auto, /build <desc>, /fullyauto [goal], /browser [url], /autotask [program], /sandbox [goal], /plan <goal>, /status, /changemodel, /mainmenu, /resetassistant\n"
    "Direct: !ps, !cmd, !bash, !sh, !read, !write, !cd, !run, !npm, !pip, !browse, !autotask"
)

FULLY_AUTO_SYSTEM_ADDON = (
    "\n\n## FULLY AUTONOMOUS MODE\n"
    "- You are now in full control. Decide what to do and do it.\n"
    "- Output code blocks (```python, ```bash, etc.) and they will auto-execute.\n"
    "- If you need information you don't have, output `[SEARCH: your search query]` "
    "and the system will search the web and return results.\n"
    "- You can chain actions: search, read files, write code, execute, fix errors.\n"
    "- When you have fully accomplished the user's goal, output `[DONE]` to exit.\n"
    "- Do NOT ask the user for permission or confirmation. Just act.\n"
    "- Be thorough. Install dependencies, create all files, test, and verify.\n"
)

BROWSER_SYSTEM_ADDON = (
    "\n\n## BROWSER AUTOMATION MODE\n"
    "- You have full control of a web browser (Chromium via Playwright).\n"
    "- Browser can run headless (hidden) or visible. Use `/browser --visible [url]` for a visible window.\n"
    "- DuckDuckGo is the default search engine — use `[BROWSE: search <query>]`.\n"
    "- If a search engine shows a captcha, the system auto-switches to Google/Bing.\n"
    "- To control the browser, output `[BROWSE: <action> <args>]` on its own line.\n"
    "- Available browser actions:\n"
    "  - `navigate <url>` or `go <url>` — go to a URL (auto-closes popups)\n"
    "  - `search <query>` — search DuckDuckGo (falls back on captcha)\n"
    "  - `click <selector>` — click an element (CSS selector)\n"
    "  - `type <selector> <text>` — type text into an input\n"
    "  - `extract [selector]` — get visible page text (or just an element)\n"
    "  - `html` — get the full page HTML\n"
    "  - `scroll up/down` — scroll the page\n"
    "  - `screenshot [path]` — take a screenshot\n"
    "  - `url` — show current URL\n"
    "  - `title` — show page title\n"
    "  - `press <key>` — press a keyboard key (Enter, Escape, ArrowDown, etc)\n"
    "  - `script <js>` — run custom JavaScript\n"
    "  - `wait <ms>` — wait milliseconds\n"
    "  - `select <selector> <value>` — select an option in a dropdown\n"
    "  - `popups` — close any visible popups/cookie banners\n"
    "  - `captcha` — check if a captcha is present on the page\n"
    "  - `solve-captcha` — attempt to click a captcha checkbox (reCAPTCHA/hCaptcha)\n"
    "  - `close` — close the browser\n"
    "- Popups (cookie banners, modals) are auto-closed after navigation and search.\n"
    "- If a captcha is detected, call `solve-captcha` to try the checkbox variant.\n"
    "- For image-based captchas, take a screenshot and present it to the user.\n"
    "- You can chain browsing with code: search, read content, write code, execute it.\n"
    "- When you have fully accomplished the user's goal, output `[BROWSER DONE]` to exit.\n"
    "- Do NOT ask the user for permission. Just browse and build.\n"
    "- Be thorough: navigate, extract data, write code, test, and verify.\n"
)

AUTOTASK_SYSTEM_ADDON = (
    "\n\n## AUTOTASK MODE (desktop automation — NOT browser mode)\n"
    "- This mode controls the mouse, keyboard, and desktop WINDOWS — NOT a web browser.\n"
    "- You are AUTOMATING PROGRAMS on the user's desktop, not browsing the web.\n"
    "- DO NOT use `[BROWSE: ...]` tokens — that is for the browser mode, not this.\n"
    "- Instead, use `[AUTOTASK: <action> <args>]` on its own line to perform desktop actions.\n"
    "- Available AUTOTASK actions (completely different from browser actions):\n"
    "  `open <program>` or `launch <program>` — open a program (e.g. notepad, calc, chrome)\n"
    "  `find <title>` or `window <title>` — find and focus a window by its title\n"
    "  `windows` or `window-list` — list all open windows on the desktop\n"
    "  `move <x> <y>` — move the mouse to screen coordinates\n"
    "  `click [x] [y]` — click the mouse at position (or current position if no coords)\n"
    "  `doubleclick [x] [y]` — double click the mouse\n"
    "  `rightclick [x] [y]` — right click the mouse\n"
    "  `drag <x1> <y1> <x2> <y2>` — drag the mouse from one point to another\n"
    "  `type <text>` — type text using the keyboard\n"
    "  `press <key>` — press a keyboard key (enter, escape, tab, up, down, f1-f12, etc)\n"
    "  `hotkey <k1> <k2> ...` — press a key combination (e.g. ctrl c, alt tab)\n"
    "  `scroll <amount>` — scroll the mouse wheel (positive=up, negative=down)\n"
    "  `screenshot [path]` — take a screenshot of the entire desktop\n"
    "  `locate <image> [confidence]` — find an image on screen by template\n"
    "  `locateall <image> [confidence]` — find all instances of an image on screen\n"
    "  `pos` or `position` — get the current mouse cursor coordinates\n"
    "  `res` or `resolution` — get the screen resolution\n"
    "  `wait <ms>` or `sleep <ms>` — wait for a number of milliseconds\n"
    "  `close` or `exit` — close the program that was opened\n"
    "- IMPORTANT: Each `[AUTOTASK: ...]` token does ONE action. Chain multiple tokens for multi-step tasks.\n"
    "- EXAMPLE: To open notepad and type something:\n"
    "  `[AUTOTASK: open notepad]`\n"
    "  `[AUTOTASK: wait 1000]`\n"
    "  `[AUTOTASK: type Hello world]`\n"
    "  `[AUTOTASK: press enter]`\n"
    "- Use `pos` to find coordinates before clicking. Use `locate` to find buttons by image.\n"
    "- When you have fully accomplished the user's goal, output `[AUTOTASK DONE]` to exit.\n"
    "- Do NOT ask the user for permission. Just automate.\n"
)

PLAN_SYSTEM_ADDON = (
    "\n\n## STRUCTURED PLAN MODE\n"
    "- You are working through a structured plan with numbered steps.\n"
    "- Review the plan below before starting any work.\n"
    "- Work step by step — complete one step before moving to the next.\n"
    "- Track your progress by outputting `[PLAN: start <step>]` when beginning a step.\n"
    "- When you complete a step, output `[PLAN: done <step>]` with a brief result summary.\n"
    "- If a step fails and cannot be fixed, output `[PLAN: fail <step> <reason>]`.\n"
    "- You can output `[PLAN: list]` at any time to see remaining steps.\n"
    "- If you get stuck on a step, try a different approach rather than giving up.\n"
    "- After the last step is done, output `[PLAN: complete]` to finish.\n"
    "- Be thorough and verify each step works before marking it done.\n"
)

INSTRUCTION_REMINDER = "[System reminder: DO NOT over-explain. Output code and commands immediately. The user wants action, not narration. If something failed, read the logs and fix it. If asked to build, build — don't discuss.]"

SEARCH_KEYWORDS = [
    "how to", "what is", "documentation", "api", "tutorial",
    "error", "bug", "fix", "solution", "example",
    "install", "setup", "config", "npm", "pip",
    "react", "flask", "django", "node", "typescript",
    "css", "html", "javascript", "python",
    "latest", "version", "update", "download", "changelog",
]
MAX_TURNS = 30


def feed_failure_logs(messages):
    failures = get_recent_failures(3)
    if failures:
        content = "[System] Recent command failures for diagnosis:\n" + "\n---\n".join(failures)
        content += "\n\nAnalyse what went wrong and suggest a fix."
        messages.append({"role": "system", "content": content})


def sanitize(text):
    return text.replace("[SEARCH:", "&#91;SEARCH:").replace("[DONE]", "&#91;DONE]")


def trim_output(output, max_chars=500):
    if len(output) > max_chars:
        return output[:max_chars] + f"\n... (truncated, {len(output)} chars total)"
    return output


def extract_code_blocks(response):
    blocks = re.findall(r'```(\w+)\n(.*?)```', response, re.DOTALL)
    return blocks


_AUTO_EXT = {
    "python": ".py", "py": ".py",
    "javascript": ".js", "js": ".js",
    "typescript": ".ts", "ts": ".ts",
    "html": ".html", "css": ".css",
    "json": ".json", "xml": ".xml",
    "yaml": ".yaml", "yml": ".yml",
    "markdown": ".md", "md": ".md",
    "sql": ".sql",
    "rust": ".rs", "go": ".go",
    "ruby": ".rb", "php": ".php",
    "bash": ".sh", "shell": ".sh", "sh": ".sh",
    "powershell": ".ps1", "cmd": ".bat",
}

_SHELL_LANGS = {"bash", "shell", "sh", "powershell", "cmd"}
_RUNNER = {lang: (lang, "shell" if lang in _SHELL_LANGS else "code")
           for lang in _AUTO_EXT}


def _format_search_results(results):
    return "\n".join(f"{i+1}. {r['title']}: {sanitize(r['body'])} [{r['href']}]"
                     for i, r in enumerate(results))


def _run_and_respond(label, output, exit_code, messages, config):
    print(f"\n{label} Output:\n{output}")
    messages.append({"role": "user",
                     "content": f"[System] {label} (exit {exit_code}):\n{trim_output(output)}"})
    if exit_code != 0:
        feed_failure_logs(messages)
    resp = generate_response(messages, config)
    print(f"\nAssistant: {resp}")
    messages.append({"role": "assistant", "content": resp})


@dataclass
class _SessionState:
    auto_search: bool = True
    auto_build: bool = False


def handle_file_execution(blocks, config, messages, auto_build=False):

    for lang, code in blocks:
        lang = lang.lower().strip()
        code = code.strip()
        if not code:
            continue

        entry = _RUNNER.get(lang)

        if auto_build:
            if entry:
                action_lang, action_type = entry
                print(f"\n[Auto] Executing {lang} code:")
                print(f"---\n{code}\n---")
                if action_type == "shell":
                    cmd_out, success = run_os_command(code, action_lang, config.get("is_admin", False))
                else:
                    cmd_out, success = run_code(code, action_lang, get_cwd())
                exit_code = success
                status = "SUCCESS" if exit_code == 0 else "FAILED"
                print(f"[Auto] {status}\n{trim_output(cmd_out, 300)}")
                messages.append({
                    "role": "user",
                    "content": f"[System] Executed {lang} code:\n{code}\nExit code: {exit_code}\nOutput:\n{trim_output(cmd_out)}"
                })
                if exit_code != 0:
                    feed_failure_logs(messages)
                    response = generate_response(messages, config)
                    print(f"\nAssistant: {response}")
                    messages.append({"role": "assistant", "content": response})
                    recovery_blocks = extract_code_blocks(response)
                    if recovery_blocks:
                        handle_file_execution(recovery_blocks, config, messages, auto_build=True)
            else:
                ext = _AUTO_EXT.get(lang, ".txt")
                fname = f"build_output{ext}"
                write_file(fname, code)
                messages.append({"role": "user", "content": f"[System] Saved {lang} code to {fname}"})
            continue

        if entry:
            action_lang, action_type = entry
            print(f"\nAssistant proposed {lang} code. Run it? (y/n/s to save): ", end="")
            choice = input().strip().lower()
            if choice == "y":
                if action_type == "shell":
                    cmd_out, success = run_os_command(code, action_lang, config.get("is_admin", False))
                else:
                    cmd_out, success = run_code(code, action_lang, get_cwd())
                print(f"\nOutput:\n{cmd_out}")
                messages.append({
                    "role": "user",
                    "content": f"[System] Executed {lang} code:\n{code}\nExit code: {success}\nOutput:\n{trim_output(cmd_out)}"
                })
                response = generate_response(messages, config)
                print(f"\nAssistant: {response}")
                messages.append({"role": "assistant", "content": response})
            elif choice == "s":
                ext = _AUTO_EXT.get(lang, ".txt")
                print(f"Filename (e.g., file{ext}): ", end="")
                fname = input().strip()
                if fname:
                    result, ok = write_file(fname, code)
                    print(result)
                    messages.append({"role": "user", "content": f"[System] Saved {lang} code to {fname}"})
        else:
            print(f"\nAssistant proposed {lang} code. Save to file? (y/n): ", end="")
            choice = input().strip().lower()
            if choice == "y":
                ext = _AUTO_EXT.get(lang, ".txt")
                print(f"Filename (e.g., file{ext}): ", end="")
                fname = input().strip()
                if fname:
                    result, ok = write_file(fname, code)
                    print(result)


def handle_fullyauto_mode(config, messages, goal=""):
    print("\n=== FULLY AUTONOMOUS MODE ===")
    print("The AI is now in full control. Type 'exit' to cancel at any time.\n")

    system_note = FULLY_AUTO_SYSTEM_ADDON
    if goal:
        system_note += f"\nThe user's goal: {goal}\n"

    messages.append({
        "role": "user",
        "content": f"[System] {system_note.strip()}"
    })

    turn_count = 0
    while True:
        turn_count += 1
        print(f"\n[FullyAuto] Turn {turn_count}/{MAX_TURNS}")
        if turn_count > MAX_TURNS:
            print("\n[FullyAuto] Max turns reached. Exiting autonomous mode.")
            break

        print("Assistant is thinking...")
        response = generate_response(messages, config)
        print(f"\nAssistant: {response}")
        messages.append({"role": "assistant", "content": response})

        if "[DONE]" in response:
            print("\n[FullyAuto] AI has completed its task. Exiting autonomous mode.")
            break

        search_matches = re.findall(r'\[SEARCH:\s*(.*?)\]', response)
        for query in search_matches:
            query = query.strip()
            if query:
                print(f"\n[FullyAuto] AI requested web search: {query}")
                results = web_search(query)
                if results:
                    ctx = "\n".join(f"{i+1}. {r['title']}: {sanitize(r['body'])} [{r['href']}]" for i, r in enumerate(results))
                    messages.append({
                        "role": "user",
                        "content": f"[System] Web search results for '{query}':\n{ctx}"
                    })
                    print("[FullyAuto] Search results fed back to AI.")
                else:
                    messages.append({
                        "role": "user",
                        "content": f"[System] Web search for '{query}' returned no results."
                    })
                    print("[FullyAuto] No search results found.")

        blocks = extract_code_blocks(response)
        if blocks:
            handle_file_execution(blocks, config, messages, auto_build=True)

        failures = get_recent_failures(2)
        if failures:
            ctx = "[System] Automatic check of recent command logs:\n" + "\n---\n".join(failures)
            ctx += "\nIf any failed, diagnose and fix before proceeding."
            messages.append({"role": "user", "content": ctx})

    print("=== EXITED FULLY AUTONOMOUS MODE ===")


def handle_autotask_mode(config, messages, state, description=""):
    print("\n=== AUTOTASK MODE ===")
    agent = AutoTaskAgent()
    deps = agent.check_deps()
    if deps:
        print(f"  {deps}")
        return

    system_note = AUTOTASK_SYSTEM_ADDON
    if description:
        system_note += (
            f"\n\nThe user's task: {description}\n"
            f"Work through this step by step using `[AUTOTASK: ...]` tokens.\n"
            f"First, figure out what program to open, then open it, then perform each action.\n"
            f"After each action, check if it worked before moving to the next.\n"
            f"When everything is done, output `[AUTOTASK DONE]`\n"
        )
    else:
        system_note += (
            f"\nThe user has a task they want you to automate on their desktop.\n"
            f"Ask them what they want to do.\n"
        )

    messages.append({
        "role": "user",
        "content": f"[System] {system_note.strip()}"
    })

    if description:
        print(f"  Task: {description}")
        print("  The AI will now work through this autonomously.\n")

    turn_count = 0
    while True:
        turn_count += 1
        if turn_count > MAX_TURNS:
            print("\n[AutoTask] Max turns reached. Exiting.")
            break

        print("Assistant is thinking...")
        response = generate_response(messages, config)
        print(f"\nAssistant: {response}")
        messages.append({"role": "assistant", "content": response})

        if "[AUTOTASK DONE]" in response:
            print("\n[AutoTask] Task complete!")
            break

        autotask_matches = re.findall(r'\[AUTOTASK:\s*(.*?)\]', response)
        for cmd in autotask_matches:
            cmd = cmd.strip()
            if cmd:
                print(f"\n[AutoTask] Executing: {cmd}")
                result = process_autotask_command(agent, cmd)
                print(f"[AutoTask] {result[:1000]}")
                messages.append({
                    "role": "user",
                    "content": f"[System] AutoTask result:\n{result[:2000]}"
                })

        if not autotask_matches and not description:
            try:
                user_input = input(f"\n[{get_cwd()}] You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nExiting autotask mode.")
                break
            if user_input.lower() == "exit":
                break
            if user_input:
                if user_input.startswith("!autotask"):
                    cmd = user_input[10:].strip()
                    if cmd:
                        r = process_autotask_command(agent, cmd)
                        print(f"[AutoTask] {r}")
                    continue
                messages.append({"role": "user", "content": user_input})

    agent.close_program()
    print("=== EXITED AUTOTASK MODE ===")


_LAST_SEEN_PLAN_STEPS = 0


def handle_plan_tokens(response_text):
    global _LAST_SEEN_PLAN_STEPS
    import re
    matches = re.findall(r'\[PLAN:\s*(.*?)\]', response_text)
    for match in matches:
        parts = match.strip().split(maxsplit=1)
        if not parts:
            continue
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        if cmd == "create":
            task_planner.clear()
            lines = [l.strip() for l in arg.split(",") if l.strip()]
            if len(lines) >= 2:
                goal = lines[0]
                steps = lines[1:]
                task_planner.create_plan(goal, steps)
                print(f"\n[Plan] Created plan: {goal} ({len(steps)} steps)")
                print(f"{task_planner.list_steps()}")
                _LAST_SEEN_PLAN_STEPS = len(steps)
            else:
                print("\n[Plan] Usage: [PLAN: create <goal>, <step 1>, <step 2>, ...]")

        elif cmd == "start":
            try:
                sid = int(arg)
                if task_planner.start_step(sid):
                    step = next((s for s in task_planner.steps if s["id"] == sid), None)
                    desc = step["description"] if step else ""
                    print(f"\n[Plan] ▶ Started step {sid}: {desc}")
                else:
                    print(f"\n[Plan] Cannot start step {sid} — not found or not pending")
            except ValueError:
                print("\n[Plan] Usage: [PLAN: start <step_number>]")

        elif cmd == "done":
            try:
                rest = arg.split(maxsplit=1)
                sid = int(rest[0])
                result = rest[1] if len(rest) > 1 else ""
                if task_planner.complete_step(sid, result):
                    step = next((s for s in task_planner.steps if s["id"] == sid), None)
                    desc = step["description"] if step else ""
                    print(f"\n[Plan] ✓ Step {sid} done: {desc}")
                    remaining = sum(1 for s in task_planner.steps if s["status"] == "pending")
                    if remaining == 0:
                        print(f"\n[Plan] All steps complete!")
                    else:
                        print(f"[Plan] {remaining} step(s) remaining")
                else:
                    print(f"\n[Plan] Step {sid} not running — cannot mark done")
            except ValueError:
                print("\n[Plan] Usage: [PLAN: done <step_number> [result]]")

        elif cmd == "fail" or cmd == "failed":
            try:
                rest = arg.split(maxsplit=1)
                sid = int(rest[0])
                reason = rest[1] if len(rest) > 1 else ""
                task_planner.fail_step(sid, reason)
                print(f"\n[Plan] ✗ Step {sid} failed: {reason}")
            except ValueError:
                pass

        elif cmd == "list":
            print(f"\n[Plan]\n{task_planner.list_steps()}")

        elif cmd == "status":
            print(f"\n[Plan]\n{task_planner.status()}")

        elif cmd == "complete":
            print(f"\n[Plan] ✓ Plan complete: {task_planner.goal}")
            task_planner.clear()

    cleaned = re.sub(r'\[PLAN:.*?\]', '', response_text).strip()
    return cleaned


def handle_plan_mode(config, messages, state, goal=""):
    task_planner.clear()
    print(f"\n=== PLAN MODE ===")
    print("The AI will break your goal into steps and work through them.")
    print("Type 'exit' to cancel at any time.\n")

    system_note = PLAN_SYSTEM_ADDON
    if goal:
        system_note += f"\nThe user's goal: {goal}\n"
        system_note += f"Break this into numbered steps (3-7 steps recommended). Create the plan first, then work through each step."
    else:
        system_note += f"\nThe user has a complex task. Ask them to describe their goal, then break it into steps."

    messages.append({
        "role": "user",
        "content": f"[System] {system_note.strip()}"
    })

    global _LAST_SEEN_PLAN_STEPS
    turn_count = 0
    while True:
        turn_count += 1
        if turn_count > 50:
            print("\n[Plan] Max turns reached. Exiting plan mode.")
            break

        try:
            user_input = input(f"\n[Plan] You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting plan mode.")
            break
        if user_input.lower() == "exit":
            break
        if user_input:
            if user_input.lower() == "/status":
                print(f"\n{task_planner.status()}")
                continue
            elif user_input.lower() in ("/help", "/?"):
                print("Commands: describe your goal, /status to see progress, exit to quit")
                continue
            messages.append({"role": "user", "content": user_input})

        print("Assistant is thinking...")
        response = generate_response(messages, config)
        cleaned = handle_plan_tokens(response)
        if cleaned:
            print(f"\nAssistant: {cleaned}")
            messages.append({"role": "assistant", "content": cleaned})

        if "[DONE]" in response or "[PLAN: complete]" in response:
            print("\n[Plan] Goal complete!")
            break

        if hasattr(state, 'auto_execute') or hasattr(state, 'build_mode'):
            pass

    task_planner.clear()
    print("=== EXITED PLAN MODE ===")


def handle_browser_mode(config, messages, url="", visible=False):
    mode_str = "VISIBLE" if visible else "HEADLESS"
    print(f"\n=== BROWSER AUTOMATION MODE ({mode_str}) ===")
    print("Starting browser...")
    browser = BrowserAgent(headless=not visible)
    msg = browser.start()
    print(msg)
    if "not installed" in msg:
        print("Install Playwright first: pip install playwright && python -m playwright install chromium")
        return

    system_note = BROWSER_SYSTEM_ADDON
    if url:
        system_note += f"\nThe user wants to visit: {url}\nFirst navigate to this URL and explore."
        result = browser.navigate(url)
        print(f"\n[Browser] {result}")
        browser.close_popups()
        captcha = browser.detect_captcha()
        if captcha:
            print(f"\n[Browser] ⚠ {captcha}")
            result += f"\n⚠ {captcha}"
        content = browser.extract()[:2000]
        system_note += f"\n\nInitial page content:\n{content}"
        system_note += f"\n\n(Auto-closed popups; captcha check done.)"

    messages.append({
        "role": "user",
        "content": f"[System] {system_note.strip()}"
    })

    print("Browser automation activated. AI will control the browser.")
    print("Type '/fullyauto <description>' to give the AI a goal, or 'exit' to cancel.\n")

    turn_count = 0
    while True:
        turn_count += 1
        if turn_count > MAX_TURNS:
            print("\n[Browser] Max turns reached. Exiting browser mode.")
            break

        try:
            user_input = input(f"\n[{get_cwd()}] You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting browser mode.")
            break
        if user_input.lower() == "exit":
            break
        if user_input:
            if user_input.lower().startswith("/fullyauto"):
                desc = user_input[11:].strip() if len(user_input) > 11 else ""
                msg = f"The user wants: {desc}" if desc else "The user is waiting for you to ask what they want."
                messages.append({"role": "user", "content": msg})
                print(f"[Browser] Goal noted: {desc or 'ask the user'}")
            elif user_input.startswith("!browse"):
                cmd = user_input[8:].strip() if len(user_input) > 8 else ""
                if cmd:
                    result = process_browse_command(browser, cmd)
                    print(f"[Browser] {result}")
                    if cmd.split()[0] == "screenshot":
                        print(f"  Screenshot saved — open the file to see the current page.")
                else:
                    print("[Browser] Usage: !browse <action> <args>")
                continue
            elif user_input.lower() in ("/help", "/?"):
                print("Commands during browser mode: /fullyauto <goal>, !browse <action>, exit")
            else:
                messages.append({"role": "user", "content": user_input})

        print("Assistant is thinking...")
        response = generate_response(messages, config)
        print(f"\nAssistant: {response}")
        messages.append({"role": "assistant", "content": response})

        if "[BROWSER DONE]" in response:
            print("\n[Browser] AI has completed its browser task.")
            break

        search_matches = re.findall(r'\[SEARCH:\s*(.*?)\]', response)
        for query in search_matches:
            query = query.strip()
            if query:
                print(f"\n[Browser] AI requested web search: {query}")
                results = web_search(query)
                if results:
                    ctx = "\n".join(f"{i+1}. {r['title']}: {sanitize(r['body'])} [{r['href']}]" for i, r in enumerate(results))
                    messages.append({
                        "role": "user",
                        "content": f"[System] Web search results for '{query}':\n{ctx}"
                    })
                else:
                    messages.append({
                        "role": "user",
                        "content": f"[System] Web search for '{query}' returned no results."
                    })

        browse_matches = re.findall(r'\[BROWSE:\s*(.*?)\]', response)
        for cmd in browse_matches:
            cmd = cmd.strip()
            if cmd:
                print(f"\n[Browser] Executing: {cmd}")
                result = process_browse_command(browser, cmd)
                print(f"[Browser] {result[:1000]}")
                messages.append({
                    "role": "user",
                    "content": f"[System] Browser result:\n{result[:2000]}"
                })
                if not visible:
                    shot = browser.screenshot()
                    print(f"[Browser] Page preview: {shot}")

        blocks = extract_code_blocks(response)
        if blocks:
            handle_file_execution(blocks, config, messages, auto_build=True)

    browser.close()
    print("=== EXITED BROWSER AUTOMATION MODE ===")


def handle_sandbox_mode(config, messages, state, goal=""):
    print("\n=== SANDBOX MODE ===")
    print("The AI works autonomously in a restricted sandbox.")
    print("Type 'exit' to cancel at any time.\n")

    sandbox_note = (
        "\n\n## SANDBOX MODE\n"
        "- You are in a sandbox environment. Work autonomously toward the user's goal.\n"
        "- Output code blocks (```python, ```bash, etc.) and they will auto-execute.\n"
        "- If you need information, output `[SEARCH: your query]` to search the web.\n"
        "- When you have accomplished the goal, output `[DONE]` to exit.\n"
        "- Do NOT modify files outside the current working directory without confirmation.\n"
        "- Be careful. Test your code before making permanent changes.\n"
    )
    if goal:
        sandbox_note += f"\nThe user's goal: {goal}\n"

    messages.append({
        "role": "user",
        "content": f"[System] {sandbox_note.strip()}"
    })

    turn_count = 0
    while True:
        turn_count += 1
        if turn_count > MAX_TURNS:
            print("\n[Sandbox] Max turns reached. Exiting.")
            break

        print("Assistant is thinking...")
        response = generate_response(messages, config)
        print(f"\nAssistant: {response}")
        messages.append({"role": "assistant", "content": response})

        if "[DONE]" in response:
            print("\n[Sandbox] Task complete!")
            break

        search_matches = re.findall(r'\[SEARCH:\s*(.*?)\]', response)
        for query in search_matches:
            query = query.strip()
            if query:
                print(f"\n[Sandbox] Searching: {query}")
                results = web_search(query)
                if results:
                    ctx = "\n".join(f"{i+1}. {r['title']}: {sanitize(r['body'])} [{r['href']}]" for i, r in enumerate(results))
                    messages.append({"role": "user", "content": f"[System] Web search results for '{query}':\n{ctx}"})

        blocks = extract_code_blocks(response)
        if blocks:
            handle_file_execution(blocks, config, messages, auto_build=True)

    print("=== EXITED SANDBOX MODE ===")


def _do_change_model(config):
    from assistant_core.provider import (get_ollama_models, get_lmstudio_models,
                                         get_api_models, pick_model)
    prov = config.get("provider_type", "")
    changed = False
    if prov == "ollama":
        models = get_ollama_models()
        if models:
            for i, m in enumerate(models):
                print(f"  {i+1}. {m}")
            config["model"] = pick_model(models)
            changed = True
        else:
            nm = input("Model name: ").strip()
            if nm:
                config["model"] = nm
                changed = True
    elif prov == "lmstudio":
        models = get_lmstudio_models()
        if models:
            for i, m in enumerate(models):
                print(f"  {i+1}. {m}")
            config["model"] = pick_model(models)
            changed = True
        else:
            nm = input("Model name: ").strip()
            if nm:
                config["model"] = nm
                changed = True
    elif prov in ("api", "huggingface"):
        nm = input("New model name: ").strip()
        if nm:
            config["model"] = nm
            changed = True
    elif prov == "airllm":
        try:
            from assistant_core import llm as _llm
            _llm._airllm_model = None
        except Exception:
            pass
        nm = input("New model path or HF repo ID: ").strip()
        if nm:
            config["model"] = nm
            changed = True
    else:
        nm = input("Model name: ").strip()
        if nm:
            config["model"] = nm
            changed = True
    if changed:
        print(f"Model changed to: {config['model']}")
    else:
        print("Model unchanged.")


def chat_loop(config):
    print(f"\n=== {get_agent_name()} ===")
    print(_HELP_TEXT)

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    state = _SessionState()
    internet_available = check_internet()
    if not internet_available:
        print("No internet detected. Web search disabled.")
        state.auto_search = False

    while True:
        try:
            user_input = input(f"\n[{get_cwd()}] You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() == "exit":
            print("Goodbye!")
            break

        if user_input.lower() in ("/help", "/?"):
            print(_HELP_TEXT)
            continue

        if user_input.lower() == "/changemodel":
            _do_change_model(config)
            continue

        if user_input.lower() == "/mainmenu":
            try:
                from assistant_core import llm as _llm
                _llm._airllm_model = None
            except Exception:
                pass
            from assistant_core.provider import select_provider
            new_cfg = select_provider()
            for k, v in new_cfg.items():
                config[k] = v
            messages.clear()
            messages.append({"role": "system", "content": SYSTEM_PROMPT})
            state.auto_build = False
            state.auto_search = True
            print("\n=== Provider changed. Starting fresh. ===")
            continue

        if user_input.lower() == "/resetassistant":
            clear_command_logs()
            try:
                from assistant_core import llm as _llm
                _llm._airllm_model = None
            except Exception:
                pass
            from planner import planner as _tp
            _tp.clear()
            messages.clear()
            messages.append({"role": "system", "content": SYSTEM_PROMPT})
            state.auto_build = False
            print("\n=== Assistant reset. Logs cleared, history wiped. ===")
            continue

        if user_input.lower().startswith("/fullyauto"):
            goal = user_input[11:].strip() if len(user_input) > 11 else ""
            handle_fullyauto_mode(config, messages, goal)
            continue

        if user_input.lower() == "/toggle":
            state.auto_search = not state.auto_search
            print(f"Auto-search is now {'ON' if state.auto_search else 'OFF'}")
            continue

        if user_input.lower() == "/auto":
            state.auto_build = not state.auto_build
            print(f"Auto-build mode is now {'ON' if state.auto_build else 'OFF'}")
            print("Code blocks from the AI will execute automatically without confirmation.")
            continue

        if user_input.lower().startswith("/build "):
            state.auto_build = True
            plan = user_input[7:].strip()
            print(f"Build mode ON. Executing: {plan}")
            messages.append({"role": "user", "content": f"[System] BUILD MODE ENABLED. Execute the following plan immediately:\n\n{plan}\n\nDo NOT narrate or explain. Output code blocks. The system auto-executes them. If a step fails, diagnose and fix. Create files, install dependencies, verify."})
            response = generate_response(messages, config)
            print(f"\nAssistant: {response}")
            messages.append({"role": "assistant", "content": response})
            blocks = extract_code_blocks(response)
            if blocks:
                handle_file_execution(blocks, config, messages, auto_build=True)
                failures = get_recent_failures(2)
                if failures:
                    ctx = "[System] Build step failures:\n" + "\n---\n".join(failures)
                    ctx += "\nAnalyse and fix before the next step."
                    messages.append({"role": "system", "content": ctx})
                    resp = generate_response(messages, config)
                    print(f"\nAssistant: {resp}")
                    messages.append({"role": "assistant", "content": resp})
                    recovery_blocks = extract_code_blocks(resp)
                    if recovery_blocks:
                        handle_file_execution(recovery_blocks, config, messages, auto_build=True)
            continue

        if user_input.lower() == "/status":
            print(f"\n{task_planner.status()}")
            continue

        if user_input.lower().startswith("/plan"):
            goal = user_input[6:].strip() if len(user_input) > 6 else ""
            handle_plan_mode(config, messages, state, goal)
            continue

        if user_input.lower().startswith("/autotask"):
            rest = user_input[10:].strip() if len(user_input) > 10 else ""
            handle_autotask_mode(config, messages, state, rest)
            continue

        if user_input.lower().startswith("/browser"):
            url = user_input[9:].strip() if len(user_input) > 9 else ""
            visible = " --visible" in url
            if visible:
                url = url.replace(" --visible", "").strip()
            handle_browser_mode(config, messages, url, visible)
            continue

        if user_input.lower().startswith("/sandbox"):
            goal = user_input[9:].strip() if len(user_input) > 9 else ""
            handle_sandbox_mode(config, messages, state, goal)
            continue

        if user_input.startswith("/logs"):
            parts = user_input.split(maxsplit=1)
            n = 5
            if len(parts) > 1:
                try:
                    n = int(parts[1])
                except ValueError:
                    print("Usage: /logs [N]")
                    continue
            logs = read_recent_logs(n)
            print(f"\n--- Last {n} command log(s) ---")
            print(logs)
            messages.append({"role": "user", "content": f"[System] Review last {n} logs:\n{logs}\nCheck for errors."})
            response = generate_response(messages, config)
            print(f"\nAssistant: {response}")
            messages.append({"role": "assistant", "content": response})
            continue

        if user_input.lower() == "/clearcommandlogs":
            count = clear_command_logs()
            print(f"Cleared {count} command log(s).")
            continue

        if user_input.lower() == "/review":
            logs = read_recent_logs(5)
            messages.append({"role": "user", "content": f"[System] Review recent commands:\n{logs}\n\nAnalyze each for mistakes."})
            response = generate_response(messages, config)
            print(f"\nAssistant: {response}")
            messages.append({"role": "assistant", "content": response})
            continue

        if user_input.lower() == "/reviewerrorlogs":
            errs = read_error_logs(5)
            if errs == "No error logs found.":
                print("No error logs found.")
                continue
            messages.append({"role": "user", "content": f"[System] Review these crash/error logs and diagnose what went wrong:\n{errs}\n\nIdentify the root cause and suggest how to fix it."})
            response = generate_response(messages, config)
            cleaned = handle_plan_tokens(response)
            display = cleaned if cleaned else response
            print(f"\nAssistant: {display}")
            messages.append({"role": "assistant", "content": display})
            continue

        if user_input.lower() == "/clearerrorlogs":
            count = clear_error_logs()
            print(f"Cleared {count} error log(s).")
            continue

        if user_input.startswith("/search "):
            query = user_input[8:].strip()
            if not query:
                print("Usage: /search <query>")
                continue
            print(f"Searching for: {query}")
            results = web_search(query)
            if results:
                ctx = _format_search_results(results)
                user_input = f"Web search results for '{query}':\n{ctx}\n\nBased on the above, answer the user's query."
            else:
                user_input = f"I searched for '{query}' but got no results. Answer as best you can."

        elif user_input.startswith("!ps "):
            cmd = user_input[4:].strip()
            if confirm_action(cmd, "powershell"):
                out, ec = run_os_command(cmd, "powershell", config.get("is_admin", False), get_cwd())
                _run_and_respond("PowerShell", out, ec, messages, config)
            continue

        elif user_input.startswith("!cmd "):
            cmd = user_input[5:].strip()
            if confirm_action(cmd, "cmd"):
                out, ec = run_os_command(cmd, "cmd", config.get("is_admin", False), get_cwd())
                _run_and_respond("CMD", out, ec, messages, config)
            continue

        elif user_input.startswith("!bash "):
            cmd = user_input[6:].strip()
            if confirm_action(cmd, "bash"):
                out, ec = run_os_command(cmd, "bash", config.get("is_admin", False), get_cwd())
                _run_and_respond("Bash", out, ec, messages, config)
            continue

        elif user_input.startswith("!sh "):
            cmd = user_input[4:].strip()
            if confirm_action(cmd, "sh"):
                out, ec = run_os_command(cmd, "sh", config.get("is_admin", False), get_cwd())
                _run_and_respond("Shell", out, ec, messages, config)
            continue

        elif user_input.startswith("!read "):
            path = user_input[6:].strip()
            content, ok = read_file(path)
            if ok:
                print(f"\n--- {os.path.abspath(os.path.expandvars(os.path.expanduser(path)))} ---")
                print(content)
                messages.append({"role": "user", "content": f"[System] Read file:\n```\n{content[:2000]}\n```"})
            else:
                print(content)
                messages.append({"role": "user", "content": f"[System] Failed to read file: {content}"})
            continue

        elif user_input.startswith("!write "):
            path = user_input[7:].strip()
            print("Paste content below. Type '---EOF---' on a new line when done:")
            lines = []
            try:
                while True:
                    line = input()
                    if line.strip() == "---EOF---":
                        break
                    lines.append(line)
            except (EOFError, KeyboardInterrupt):
                print("\nWrite cancelled.")
                continue
            content = "\n".join(lines)
            result, ok = write_file(path, content)
            print(result)
            if ok:
                messages.append({"role": "user", "content": f"[System] Wrote file {path} ({len(content)} chars)"})
            continue

        elif user_input.startswith("!cd "):
            path = user_input[4:].strip()
            result, ok = set_working_dir(path)
            print(result)
            continue

        elif user_input.startswith("!run "):
            path = user_input[5:].strip()
            out, ec = run_script(path, get_cwd())
            _run_and_respond("Script", out, ec, messages, config)
            continue

        elif user_input.startswith("!npm "):
            args = user_input[5:].strip()
            out, ec = run_npm(args, get_cwd())
            _run_and_respond("npm", out, ec, messages, config)
            continue

        elif user_input.startswith("!pip "):
            args = user_input[5:].strip()
            out, ec = run_pip(args, get_cwd())
            _run_and_respond("pip", out, ec, messages, config)
            continue

        elif user_input.startswith("!autotask"):
            agent = AutoTaskAgent()
            deps = agent.check_deps()
            if deps:
                print(deps)
            else:
                cmd = user_input[10:].strip() if len(user_input) > 10 else ""
                if cmd:
                    result = process_autotask_command(agent, cmd)
                    print(result)
                    messages.append({"role": "user", "content": f"[System] AutoTask: {result[:2000]}"})
            continue
        elif user_input.startswith("!browse"):
            browser = BrowserAgent(headless=True)
            msg = browser.start()
            print(msg)
            if "not installed" not in msg:
                cmd = user_input[8:].strip() if len(user_input) > 8 else ""
                if cmd:
                    result = process_browse_command(browser, cmd)
                    print(result)
                    messages.append({"role": "user", "content": f"[System] Browser: {result[:2000]}"})
                browser.close()
            continue
        else:
            if state.auto_search and internet_available:
                should_search = any(kw in user_input.lower() for kw in SEARCH_KEYWORDS)
                if should_search:
                    print("(Searching web for context...)")
                    results = web_search(user_input)
                    if results:
                        ctx = _format_search_results(results)
                        user_input = f"Web search results:\n{ctx}\n\nUser question: {user_input}\n\nThink step by step."
                    else:
                        print("No search results found.")

        messages.append({"role": "user", "content": user_input})

        if len(messages) % 10 == 0 and len(messages) > 1:
            messages.append({"role": "system", "content": INSTRUCTION_REMINDER})

        if len(messages) > 1 + (MAX_TURNS * 2):
            tail = messages[-(MAX_TURNS * 2):]
            if len(tail) % 2 != 0:
                tail = tail[1:]
            messages = [messages[0]] + tail

        print("Assistant is thinking...")
        response = generate_response(messages, config)
        cleaned = handle_plan_tokens(response)
        display = cleaned if cleaned else response
        if display != response:
            response = cleaned
        print(f"\nAssistant: {display}")
        messages.append({"role": "assistant", "content": display})

        blocks = extract_code_blocks(response)
        if blocks:
            handle_file_execution(blocks, config, messages, auto_build)


def _install_error_hook():
    import traceback
    original = sys.excepthook
    def _hook(etype, value, tb):
        tb_str = "".join(traceback.format_exception(etype, value, tb))
        try:
            log_error(tb_str)
        except Exception:
            pass
        original(etype, value, tb)
    sys.excepthook = _hook


def main():
    _install_error_hook()
    print(f"=== {get_agent_name()} ===")
    print(f"An AI assistant for building apps, websites, and writing code on {get_os_name()}.")
    try:
        admin_choice = input("Run commands as admin? (y/n): ").lower().strip()
    except (EOFError, KeyboardInterrupt):
        print("\nExiting.")
        sys.exit(0)
    is_admin = admin_choice == 'y'
    if is_admin:
        print("\nWARNING: Admin mode grants commands elevated privileges.")
        print("The AI may execute commands that modify system files, registry, or services.")
        try:
            confirm = input("Are you sure you want to continue with admin mode? (y/n): ").lower().strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            sys.exit(0)
        if confirm != 'y':
            print("Falling back to normal user mode.")
            is_admin = False
    print(f"{'Admin' if is_admin else 'Normal user'} mode selected")

    config = select_provider()
    config["is_admin"] = is_admin
    chat_loop(config)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nGoodbye!")
        sys.exit(0)
