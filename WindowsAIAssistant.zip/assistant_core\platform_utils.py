import sys
import os


def get_os():
    if sys.platform == "win32":
        return "windows"
    elif sys.platform == "darwin":
        return "macos"
    return "linux"


def get_os_name():
    return {"windows": "Windows", "macos": "macOS", "linux": "Linux"}[get_os()]


def get_agent_name():
    return f"{get_os_name()}DevAgent"


def get_shell():
    if sys.platform == "win32":
        return {
            "name": "powershell",
            "shell_name": "powershell",
            "cmd": ["powershell.exe", "-Command"],
            "ext": ".ps1",
            "alt_name": "cmd",
            "alt_cmd": ["cmd.exe", "/c"],
            "alt_ext": ".bat",
        }
    return {
        "name": "bash",
        "shell_name": "bash",
        "cmd": ["/bin/bash", "-c"],
        "ext": ".sh",
        "alt_name": "sh",
        "alt_cmd": ["/bin/sh", "-c"],
        "alt_ext": ".sh",
    }


def get_shell_prompt_hint():
    if sys.platform == "win32":
        return "- Prefer PowerShell for system commands"
    return "- Prefer Bash (or sh) for system commands"


def get_script_handler(ext):
    ext = ext.lower()
    if sys.platform == "win32":
        return {
            ".py": ["python", "{path}"],
            ".js": ["node", "{path}"],
            ".ts": ["npx", "tsx", "{path}"],
            ".ps1": ["powershell", "-File", "{path}"],
            ".bat": ["{path}"],
            ".cmd": ["{path}"],
            ".rb": ["ruby", "{path}"],
            ".go": ["go", "run", "{path}"],
            ".rs": ["rustc", "{path}"],
            ".php": ["php", "{path}"],
            ".sh": ["bash", "{path}"],
        }.get(ext)
    return {
        ".py": ["python3", "{path}"],
        ".js": ["node", "{path}"],
        ".ts": ["npx", "tsx", "{path}"],
        ".sh": ["bash", "{path}"],
        ".rb": ["ruby", "{path}"],
        ".go": ["go", "run", "{path}"],
        ".rs": ["rustc", "{path}"],
        ".php": ["php", "{path}"],
        ".ps1": ["pwsh", "-File", "{path}"],
        ".bat": ["wine", "{path}"],
        ".cmd": ["wine", "{path}"],
    }.get(ext)


def open_program_args(target):
    if sys.platform == "win32":
        return ["cmd.exe", "/c", "start", "", target]
    elif sys.platform == "darwin":
        return ["open", "-a", target]
    return [target]


def get_npm_cmd(args):
    if sys.platform == "win32":
        return ["cmd", "/c", f"npm {args}"]
    return ["/bin/sh", "-c", f"npm {args}"]
