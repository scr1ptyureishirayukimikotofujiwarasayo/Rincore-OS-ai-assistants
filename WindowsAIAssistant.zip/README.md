# Windows OS AI Assistant

An AI-powered assistant for Windows that can execute PowerShell and CMD commands, write and run code, build projects, search the web, and answer questions using local or cloud AI models.

## Features

- **Multiple AI backends**: Ollama (local), LM Studio (local), or API-based (OpenAI, Anthropic, OpenRouter, DeepSeek, custom)
- **System command execution**: Run PowerShell (`!ps`) or CMD (`!cmd`) commands directly
- **File operations**: Read (`!read`) and write (`!write`) files directly
- **Code execution**: Run code in Python, JavaScript, TypeScript, Rust, Go, Ruby, PHP, and more via `!run`
- **Package management**: Install packages with `!pip` and `!npm`
- **AI-driven code proposals**: The AI outputs code blocks (```python, ```javascript, etc.) for you to review, run, or save
- **Auto-execute mode** (`/auto`): Automatically runs AI code blocks without confirmation
- **Build mode** (`/build <desc>`): Autonomous multi-step build workflow — AI plans, creates files, installs deps, and verifies
- **Fully autonomous mode** (`/fullyauto <desc>`): Full AI autonomy — decides what to do, when to search the web, and what code to execute, chaining actions until the goal is complete
- **Web search**: Automatic or manual web search via DuckDuckGo
- **Self-updating search engine**: Automatically checks for and applies `ddgs` library updates from PyPI
- **Browser automation**: Control a real web browser via Playwright — navigate, click, type, extract data, take screenshots (`/browser` mode or `!browse` direct command)
- **DuckDuckGo search in browser**: Default search engine in browser mode is DuckDuckGo, with full page interaction
- **Admin mode toggle**: Flag commands as admin-level (informational — actual elevation requires running terminal as Administrator)
- **Command logging**: Each executed command is logged to `command_logs/` with structured files
- **Automatic error troubleshooting**: When a command or code execution fails, the system automatically attaches recent failure logs so the AI can diagnose the root cause
- **Action review**: Use `/logs` and `/review` to have the AI inspect past commands for mistakes
- **Conversation context management**: Automatically trims history to prevent model confusion

## Requirements

- Python 3.7+
- One of the following AI backends:
  - [Ollama](https://ollama.com) — run models locally
  - [LM Studio](https://lmstudio.ai) — run models locally
  - An API key from [OpenAI](https://openai.com), [Anthropic](https://claude.ai), [OpenRouter](https://openrouter.ai), [DeepSeek](https://deepseek.com), etc.

## Installation

```bash
pip install -r requirements.txt
python -m playwright install chromium
```

## Usage

```bash
python main.py
```

The assistant will guide you through:
1. **Admin mode** — choose whether commands should run with admin privileges
2. **AI provider** — select Ollama, LM Studio, or API key provider
3. **Model selection** — pick from available models
4. **Chat loop** — interact with the AI

### Chat Commands

| Command | Description |
|---------|-------------|
| `exit` | Exit the assistant |
| `/search <query>` | Force a web search on any topic |
| `/toggle` | Enable/disable automatic web search |
| `/logs [N]` | Show the last N command logs and have the AI review them |
| `/clearcommandlogs` | Delete all command logs from command_logs/ |
| `/review` | Have the AI inspect recent commands for mistakes |
| `/auto` | Toggle auto-execution — AI code blocks run without confirmation |
| `/build <desc>` | Start auto-build mode — AI plans and executes a multi-step build autonomously |
| `/fullyauto <desc>` | Start fully autonomous mode — AI takes full control, including web searches, until the goal is complete or outputs `[DONE]` |
| `/browser [--visible] [url]` | Enter browser automation mode — AI controls a web browser via Playwright (add `--visible` to watch it) |

### Direct Commands

| Command | Description |
|---------|-------------|
| `!ps <command>` | Execute a PowerShell command directly |
| `!cmd <command>` | Execute a CMD command directly |
| `!read <path>` | Read and display a file's contents |
| `!write <path>` | Write content to a file (paste content, end with `---EOF---`) |
| `!cd <dir>` | Change the working directory |
| `!run <script>` | Execute a script file by path |
| `!npm <args>` | Run npm commands (install, build, test, etc.) |
| `!pip <args>` | Run pip commands (install, uninstall, list, etc.) |
| `!browse <action>` | Direct browser command (go, click, type, extract, screenshot, etc.) |

### Supported Languages for Code Execution

Python (`py`), JavaScript (`js`), TypeScript (`ts`), Rust, Go, Ruby, PHP, HTML, CSS, JSON, XML, YAML, Markdown, SQL.

Runnable languages execute via temp files. Non-runnable languages (HTML, CSS, JSON, etc.) prompt you to save to a file.

### How AI Code Execution Works

1. Ask the AI to perform a task (e.g., *"create a flask web app"*)
2. The AI responds with code in language-labelled blocks: ```python, ```javascript, etc.
3. In normal mode, you **review and confirm** before code runs
4. In auto mode (`/auto` or `/build`), blocks execute automatically
5. The output is fed back to the AI for further discussion

### Automatic Error Troubleshooting

When any command or code execution fails, the system automatically pulls the last 3 failed command logs and injects them into the conversation as context for the AI. This allows the AI to:

- Trace the sequence of events that led to the failure
- Distinguish between root cause and downstream errors
- Propose targeted fixes based on the full command history

This happens transparently in all modes — normal, build, and fully autonomous. No manual `/review` needed for error diagnosis.

### Command Logs

Every executed command is saved as an individual file in `command_logs/`:

```
cmd_20260515_045231_0003.log
  Timestamp : 2026-05-15 04:52:31
  Shell     : powershell
  Exit Code : 1
  Status    : FAILED
  Command   : Get-Service BrokenService
  ============================================================
  Output:
  Cannot find service
```

Use `/logs 5` to show recent logs, or `/review` to have the AI check its past commands for errors.

### Auto-Updating Search Engine

The search library (`ddgs`) is automatically checked against PyPI once per day. If a newer version is available, it's updated in the background before the next search. Disable this in `assistant_core/config.json`:

```json
{"auto_update": false, "auto_update_interval_hours": 24}
```

## Model Sources

| Source | Type | URL |
|--------|------|-----|
| Ollama | Local & Cloud | https://ollama.com |
| HuggingFace | Local & Cloud | https://huggingface.co |
| OpenRouter | Cloud (API key) | https://openrouter.ai |
| OpenAI | Cloud (API key) | https://openai.com |
| Anthropic | Cloud (API key) | https://claude.ai |
| DeepSeek | Cloud (API key) | https://deepseek.com |

## Important Notes

- The assistant has limited context memory (last ~30 turns). Excessive history can confuse the model.
- This is not a system repair tool. The AI can make mistakes. Always review commands before execution.
- For complex tasks, use larger models (e.g., Qwen3-Coder:480B) via cloud API if your local hardware is insufficient.
- Larger parameter models (more "brain size") generally produce better results for complex tasks.

## Project Structure

```
WindowsAIAssistant/
├── COMMANDS.txt              # Full command reference
├── main.py                   # Entry point and chat loop
├── executor.py               # PowerShell/CMD execution, file ops, code runner
├── browser_agent.py          # Playwright-based browser automation
├── .gitignore
├── LICENSE
├── MODEL_RECOMMENDATIONS.md
├── README.md
├── requirements.txt
├── command_logs/             # Per-command execution logs
│   └── .gitkeep
└── assistant_core/
    ├── __init__.py
    ├── config.json           # Auto-update settings
    ├── llm.py                # LLM API communication
    ├── provider.py           # AI provider selection and model listing
    ├── search.py             # Low-level DuckDuckGo search
    ├── search_engine.py      # Search interface with auto-update
    └── update_manager.py     # PyPI version check and package update
```
